# Power BI Build Guide (≈ 45–60 minutes)

> **Honest note:** a `.pbix` file can only be created inside Power BI Desktop (Windows). Everything needed to build it is provided here:
> clean data, a ready theme, all DAX measures, Power Query code and exact visual layout. A working browser version of the same dashboard
> is in `Interactive_Dashboard.html`, and a picture of the target layout is in `../Screenshots/00_dashboard_overview.png`.
> Once you build the `.pbix`, save it in this folder as `Sales_MIS_Dashboard.pbix` and take your own screenshots.

## Step 1 – Load data
1. Open **Power BI Desktop** (free, Microsoft Store) → **Home → Get data → Text/CSV**.
2. Load these 4 files from `../Dataset/`: `sales_cleaned.csv`, `products.csv`, `salespeople.csv`, `customers.csv` (click **Transform Data** instead of Load to check types; code in `PowerQuery_Load.m`).
3. Rename queries to **Sales, Products, Salespeople, Customers**. Confirm *Order Date* = Date, money columns = Whole number.

## Step 2 – Date table and relationships
1. **Modeling → New table** → paste the `Date = ...` code from `DAX_Measures.dax`. Mark it as date table. Sort `Month` by `Month Sort`.
2. **Model view** → create (drag) these relationships, all *Many-to-One, single direction*:
   | From (Many) | To (One) |
   |---|---|
   | Sales[Order Date] | Date[Date] |
   | Sales[Product Name] | Products[product_name] |
   | Sales[Salesperson] | Salespeople[salesperson_name] |
   | Sales[Customer ID] | Customers[customer_id] |

## Step 3 – Measures
Create each measure in `DAX_Measures.dax` (**Modeling → New measure**). Put them in a table called `_Measures` (Enter data → blank table) to stay organised.
Check: Total Revenue = **₹31,232,361**, Orders = **4,904**, Customers = **570**, Margin = **32.77%**.

## Step 4 – Theme and canvas
**View → Themes → Browse for themes** → `Sales_MIS_Theme.json`. Page size: 16:9 (1280 × 720). Page background is applied by the theme.

## Step 5 – Page layout (1280 × 720)
| Zone | Visual | Fields | Position (x, y, w, h) |
|---|---|---|---|
| Title bar | Text box "Sales MIS Reporting & Business Performance Dashboard" | – | 20, 10, 800, 40 |
| Slicers (row) | **Date** (Between slicer), **Region** (dropdown), **Category** (dropdown), **Salesperson** (dropdown) | Date[Date], Sales[Region], Sales[Category], Sales[Salesperson] | y = 55, h = 50, each w ≈ 240 |
| KPI cards ×6 | **Card** visual | Total Revenue, Total Profit, Total Orders, Total Customers, Avg Order Value, Profit Margin % | y = 115, h = 85, w = 195, x = 20 + 205×n |
| Monthly Revenue Trend | **Line chart** (or Area) | X = Date[Month], Y = Total Revenue (+ tooltip: MoM %) | 20, 210, 620, 240 |
| Region-wise Sales | **Clustered bar** | Y = Sales[Region], X = Total Revenue, data labels on | 650, 210, 300, 240 |
| Category-wise Revenue | **Donut** | Legend = Sales[Category], Values = Total Revenue | 960, 210, 300, 240 |
| Top 10 Products | **Bar chart** | Y = Sales[Product Name], X = Total Revenue → Filters pane: **Top N = 10 by Total Revenue** | 20, 460, 420, 250 |
| Salesperson Performance | **Bar chart** | Y = Sales[Salesperson], X = Total Revenue, tooltip = Target Achievement % | 450, 460, 420, 250 |
| Order Status Analysis | **Column chart** (or Funnel) | X = Sales[Order Status], Y = All Orders *(measure ignores valid filter)* | 880, 460, 380, 250 |

## Step 6 – Interactivity
* **Sync slicers** across pages: View → Sync slicers.
* Click any bar/slice → other visuals cross-filter automatically. Use **Edit interactions** to stop a visual filtering another.
* Add a **Reset** button: Insert → Buttons → Clear all slicers (Power BI 2023+), or use a Bookmark of the default state.
* **Drill-through page** "Product Detail": drag Product Name to *Drill through* well; add a table of Order ID, Date, Customer, Revenue, Profit.
* Conditional formatting on *Profit Margin %* card: Field value → `Margin Colour` measure.

## Step 7 – Publish and screenshots
1. Save as `Sales_MIS_Dashboard.pbix` inside this folder.
2. Take screenshots (Win + Shift + S): full page, Region slicer applied (e.g., West), a drill-through page → save in `../Screenshots/` (e.g. `pbi_01_overview.png`).
3. Optional: Home → Publish → My workspace → put the link in your README/LinkedIn.

## Common mistakes (interviewers ask these!)
* Using `SUM(Revenue)` without the valid filter → Revenue becomes ₹3.57 Cr instead of ₹3.12 Cr.
* Totals of Customers don't add across regions – `DISTINCTCOUNT` is not additive (that is correct behaviour).
* Month axis sorting alphabetically → fix with *Sort by column*.
