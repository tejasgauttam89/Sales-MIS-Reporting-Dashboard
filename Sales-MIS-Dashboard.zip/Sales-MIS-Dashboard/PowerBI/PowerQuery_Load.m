// =====================================================================
// PowerQuery_Load.m  |  Home > Transform data > New Source > Blank Query > Advanced Editor > paste
// Change the folder path in  DataPath  to where you saved the Dataset folder.
// =====================================================================

// ---------- QUERY 1 : Sales  (load the CLEANED file) ----------
let
    DataPath = "C:\Users\YourName\Sales-MIS-Dashboard\Dataset\",
    Source   = Csv.Document(File.Contents(DataPath & "sales_cleaned.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Header   = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed    = Table.TransformColumnTypes(Header, {
                 {"Order Date", type date}, {"Quantity", Int64.Type}, {"Unit Price", Int64.Type}, {"Revenue", Int64.Type},
                 {"Cost", Int64.Type}, {"Profit", Int64.Type}, {"Year", Int64.Type}, {"Net Revenue", Int64.Type}, {"Net Profit", Int64.Type},
                 {"Order ID", type text}, {"Customer ID", type text}, {"Customer Name", type text}, {"Product Name", type text},
                 {"Category", type text}, {"Region", type text}, {"Salesperson", type text}, {"Payment Mode", type text},
                 {"Order Status", type text}, {"Month", type text}, {"Valid Sale", type text}})
in
    Typed

// ---------- QUERY 2-4 : Products / Salespeople / Customers (same pattern; change file name) ----------
// let
//     DataPath = "C:\Users\YourName\Sales-MIS-Dashboard\Dataset\",
//     Source = Csv.Document(File.Contents(DataPath & "products.csv"), [Delimiter=",", Encoding=65001]),
//     Header = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
//     Typed  = Table.TransformColumnTypes(Header, {{"list_price", Int64.Type}, {"unit_cost", Int64.Type}})
// in  Typed
//   salespeople.csv -> {"target", Int64.Type}        customers.csv -> no number columns

// ---------- OPTIONAL (shows cleaning skills): clean the RAW file inside Power Query instead ----------
// let
//     Source  = Csv.Document(File.Contents("C:\...\Dataset\sales_raw.csv"), [Delimiter=",", Encoding=65001]),
//     Header  = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
//     Trim    = Table.TransformColumns(Header, {{"Customer Name", Text.Trim, type text}, {"Region", Text.Trim, type text}}),
//     Proper  = Table.TransformColumns(Trim, {{"Customer Name", Text.Proper, type text}, {"Region", Text.Proper, type text}, {"Order Status", Text.Proper, type text}}),
//     NoDupes = Table.Distinct(Proper),                                       // remove duplicate rows
//     PayFix  = Table.ReplaceValue(NoDupes, null, "Unknown", Replacer.ReplaceValue, {"Payment Mode"}),
//     DateFix = Table.TransformColumnTypes(PayFix, {{"Order Date", type date}}, "en-GB")   // handles dd/mm/yyyy
// in  DateFix
