-- =====================================================================
-- 01_create_tables.sql   |  Sales MIS Project
-- Works in SQLite (used to build sales_mis.db) and MySQL 8 (see notes).
-- Business rule used everywhere:  VALID SALE = order_status NOT IN ('Cancelled','Returned')
-- =====================================================================
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS salespeople;
DROP TABLE IF EXISTS customers;

CREATE TABLE products (
    product_id    VARCHAR(10) PRIMARY KEY,
    product_name  VARCHAR(60) NOT NULL,
    category      VARCHAR(30) NOT NULL,
    list_price    INT,
    unit_cost     INT
);

CREATE TABLE salespeople (
    salesperson_id    VARCHAR(10) PRIMARY KEY,
    salesperson_name  VARCHAR(50) NOT NULL,
    region            VARCHAR(20),
    target            INT            -- 2-year revenue target (INR)
);

CREATE TABLE customers (
    customer_id    VARCHAR(12) PRIMARY KEY,
    customer_name  VARCHAR(60),
    region         VARCHAR(20)
);

CREATE TABLE sales (
    order_id       VARCHAR(15) PRIMARY KEY,
    order_date     DATE NOT NULL,             -- stored as YYYY-MM-DD
    customer_id    VARCHAR(12),
    customer_name  VARCHAR(60),
    product_name   VARCHAR(60),
    category       VARCHAR(30),
    region         VARCHAR(20),
    salesperson    VARCHAR(50),
    quantity       INT,
    unit_price     INT,
    revenue        INT,
    cost           INT,
    profit         INT,
    payment_mode   VARCHAR(20),
    order_status   VARCHAR(15),
    year           INT,
    month          VARCHAR(7),                -- YYYY-MM
    valid_sale     CHAR(3),                   -- Yes / No
    net_revenue    INT,
    net_profit     INT
);

CREATE INDEX idx_sales_date   ON sales(order_date);
CREATE INDEX idx_sales_region ON sales(region);

-- ---------------------------------------------------------------------
-- LOADING DATA
--  * SQLite  : just run  python ../Python/05_build_sqlite_db.py  (creates sales_mis.db with everything loaded)
--  * MySQL   : Table Data Import Wizard (right-click table > Import) OR
--      LOAD DATA LOCAL INFILE '../Dataset/sales_cleaned.csv' INTO TABLE sales
--      FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' IGNORE 1 LINES;
--      (do the same for products.csv, salespeople.csv, customers.csv)
-- ---------------------------------------------------------------------
