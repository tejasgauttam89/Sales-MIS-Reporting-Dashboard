-- =====================================================================
-- 04_business_analysis.sql  |  The reports a manager actually asks for
-- Date note: SUBSTR(order_date,1,7) gives 'YYYY-MM' in SQLite & MySQL.
-- (MySQL alternative: DATE_FORMAT(order_date,'%Y-%m'); SQLite alternative: strftime('%Y-%m',order_date))
-- =====================================================================

-- Q18. Headline KPIs
SELECT SUM(revenue)                                        AS total_revenue,
       SUM(profit)                                         AS total_profit,
       COUNT(*)                                            AS total_orders,
       COUNT(DISTINCT customer_id)                         AS total_customers,
       ROUND(SUM(revenue) * 1.0 / COUNT(*), 2)             AS avg_order_value,
       ROUND(100.0 * SUM(profit) / SUM(revenue), 2)        AS profit_margin_pct
FROM sales
WHERE valid_sale = 'Yes';

-- Q19. Monthly revenue analysis with Month-over-Month growth (window function LAG)
WITH m AS (
    SELECT SUBSTR(order_date, 1, 7) AS month, COUNT(*) AS orders, SUM(revenue) AS revenue, SUM(profit) AS profit
    FROM sales WHERE valid_sale = 'Yes' GROUP BY SUBSTR(order_date, 1, 7)
)
SELECT month, orders, revenue, profit,
       ROUND(100.0 * profit / revenue, 2) AS margin_pct,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month)) / LAG(revenue) OVER (ORDER BY month), 2) AS mom_growth_pct
FROM m
ORDER BY month;

-- Q20. Year-on-year comparison by month number
SELECT SUBSTR(order_date, 6, 2) AS month_no,
       SUM(CASE WHEN year = 2024 THEN revenue ELSE 0 END) AS rev_2024,
       SUM(CASE WHEN year = 2025 THEN revenue ELSE 0 END) AS rev_2025,
       ROUND(100.0 * (SUM(CASE WHEN year = 2025 THEN revenue ELSE 0 END) - SUM(CASE WHEN year = 2024 THEN revenue ELSE 0 END))
             / SUM(CASE WHEN year = 2024 THEN revenue ELSE 0 END), 1) AS yoy_growth_pct
FROM sales WHERE valid_sale = 'Yes'
GROUP BY SUBSTR(order_date, 6, 2)
ORDER BY month_no;

-- Q21. TOP 10 products by revenue
SELECT product_name, category, SUM(quantity) AS units_sold, SUM(revenue) AS revenue, SUM(profit) AS profit,
       ROUND(100.0 * SUM(profit) / SUM(revenue), 2) AS margin_pct,
       RANK() OVER (ORDER BY SUM(revenue) DESC) AS revenue_rank
FROM sales WHERE valid_sale = 'Yes'
GROUP BY product_name, category
ORDER BY revenue DESC
LIMIT 10;

-- Q22. Region-wise performance with share of total
SELECT region, COUNT(*) AS orders, SUM(revenue) AS revenue, SUM(profit) AS profit,
       ROUND(100.0 * SUM(profit) / SUM(revenue), 2) AS margin_pct,
       ROUND(100.0 * SUM(revenue) / (SELECT SUM(revenue) FROM sales WHERE valid_sale = 'Yes'), 2) AS revenue_share_pct,
       ROUND(SUM(revenue) * 1.0 / COUNT(*), 0) AS avg_order_value
FROM sales WHERE valid_sale = 'Yes'
GROUP BY region
ORDER BY revenue DESC;

-- Q23. Profit analysis: category x margin with rank, and share of total profit
SELECT category, SUM(profit) AS profit,
       ROUND(100.0 * SUM(profit) / (SELECT SUM(profit) FROM sales WHERE valid_sale = 'Yes'), 2) AS share_of_profit_pct,
       ROUND(100.0 * SUM(profit) / SUM(revenue), 2) AS margin_pct,
       RANK() OVER (ORDER BY 100.0 * SUM(profit) / SUM(revenue) DESC) AS margin_rank
FROM sales WHERE valid_sale = 'Yes'
GROUP BY category;

-- Q24. Top 5 most profitable products, and the 5 least profitable
SELECT * FROM (SELECT product_name, SUM(profit) AS profit FROM sales WHERE valid_sale = 'Yes' GROUP BY product_name ORDER BY profit DESC LIMIT 5)
UNION ALL
SELECT * FROM (SELECT product_name, SUM(profit) AS profit FROM sales WHERE valid_sale = 'Yes' GROUP BY product_name ORDER BY profit ASC LIMIT 5);

-- Q25. Salesperson leaderboard with rank inside their own region
SELECT salesperson, region, COUNT(*) AS orders, SUM(revenue) AS revenue,
       RANK() OVER (PARTITION BY region ORDER BY SUM(revenue) DESC) AS rank_in_region,
       RANK() OVER (ORDER BY SUM(revenue) DESC) AS overall_rank
FROM sales WHERE valid_sale = 'Yes'
GROUP BY salesperson, region
ORDER BY overall_rank;

-- Q26. Cancellation / return leakage by category (value lost)
SELECT category,
       SUM(CASE WHEN order_status = 'Cancelled' THEN revenue ELSE 0 END) AS cancelled_value,
       SUM(CASE WHEN order_status = 'Returned'  THEN revenue ELSE 0 END) AS returned_value,
       ROUND(100.0 * SUM(CASE WHEN order_status = 'Returned' THEN 1 ELSE 0 END) / COUNT(*), 2) AS return_rate_pct
FROM sales GROUP BY category ORDER BY return_rate_pct DESC;

-- Q27. Running (cumulative) revenue by month
WITH m AS (SELECT SUBSTR(order_date,1,7) AS month, SUM(revenue) AS revenue FROM sales WHERE valid_sale='Yes' GROUP BY 1)
SELECT month, revenue, SUM(revenue) OVER (ORDER BY month) AS cumulative_revenue FROM m ORDER BY month;

-- Q28. Data-quality check: any order where revenue <> quantity x unit_price, or profit <> revenue - cost? (expect 0 rows)
SELECT order_id FROM sales WHERE revenue <> quantity * unit_price OR profit <> revenue - cost;
