-- =====================================================================
-- 02_select_where_groupby.sql  |  SELECT, WHERE, ORDER BY, GROUP BY, HAVING
-- =====================================================================

-- Q1. Preview the first 10 orders
SELECT * FROM sales LIMIT 10;

-- Q2. Total records, date range and number of unique customers
SELECT COUNT(*) AS total_orders, MIN(order_date) AS first_order, MAX(order_date) AS last_order,
       COUNT(DISTINCT customer_id) AS unique_customers
FROM sales;

-- Q3. WHERE + AND: Delivered Electronics orders in the West region above Rs 50,000
SELECT order_id, order_date, product_name, quantity, revenue, salesperson
FROM sales
WHERE order_status = 'Delivered' AND category = 'Electronics' AND region = 'West' AND revenue > 50000
ORDER BY revenue DESC;

-- Q4. WHERE with IN / BETWEEN / LIKE: Q4-2025 UPI or Wallet orders for products starting with 'Smart'
SELECT order_id, order_date, product_name, payment_mode, revenue
FROM sales
WHERE order_date BETWEEN '2025-10-01' AND '2025-12-31'
  AND payment_mode IN ('UPI', 'Wallet')
  AND product_name LIKE 'Smart%'
ORDER BY order_date;

-- Q5. Order status summary (count, value, % of orders)
SELECT order_status, COUNT(*) AS orders, SUM(revenue) AS booked_value,
       ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM sales), 2) AS pct_of_orders
FROM sales
GROUP BY order_status
ORDER BY orders DESC;

-- Q6. GROUP BY: Category-wise revenue, profit and margin (valid sales only)
SELECT category, COUNT(*) AS orders, SUM(revenue) AS revenue, SUM(profit) AS profit,
       ROUND(100.0 * SUM(profit) / SUM(revenue), 2) AS margin_pct
FROM sales
WHERE valid_sale = 'Yes'
GROUP BY category
ORDER BY revenue DESC;

-- Q7. HAVING: Customers with at least 15 valid orders (loyal customers)
SELECT customer_id, customer_name, COUNT(*) AS orders, SUM(revenue) AS total_spent
FROM sales
WHERE valid_sale = 'Yes'
GROUP BY customer_id, customer_name
HAVING COUNT(*) >= 15
ORDER BY total_spent DESC;

-- Q8. HAVING: Products whose margin is below 25% (candidates for price review)
SELECT product_name, category, SUM(revenue) AS revenue,
       ROUND(100.0 * SUM(profit) / SUM(revenue), 2) AS margin_pct
FROM sales
WHERE valid_sale = 'Yes'
GROUP BY product_name, category
HAVING 100.0 * SUM(profit) / SUM(revenue) < 25
ORDER BY margin_pct;

-- Q9. Payment-mode analysis with cancellation rate
SELECT payment_mode, COUNT(*) AS orders,
       SUM(CASE WHEN order_status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled,
       ROUND(100.0 * SUM(CASE WHEN order_status = 'Cancelled' THEN 1 ELSE 0 END) / COUNT(*), 2) AS cancel_rate_pct
FROM sales
GROUP BY payment_mode
ORDER BY cancel_rate_pct DESC;
