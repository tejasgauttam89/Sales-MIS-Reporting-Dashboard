# Sample query results (first 12 rows of each query)

## Q1. Preview the first 10 orders  (02_select_where_groupby.sql)
Rows returned: 10

| order_id   | order_date   | customer_id   | customer_name   | product_name           | category        | region   | salesperson     |   quantity |   unit_price |   revenue |   cost |   profit | payment_mode   | order_status   |   year | month   | valid_sale   |   net_revenue |   net_profit |
|:-----------|:-------------|:--------------|:----------------|:-----------------------|:----------------|:---------|:----------------|-----------:|-------------:|----------:|-------:|---------:|:---------------|:---------------|-------:|:--------|:-------------|--------------:|-------------:|
| ORD-100001 | 2024-01-01   | CUST-0139     | Vijay Banerjee  | Phone Case             | Accessories     | West     | Rohan Mehta     |         13 |          499 |      6487 |   1924 |     4563 | UPI            | Delivered      |   2024 | 2024-01 | Yes          |          6487 |         4563 |
| ORD-100002 | 2024-01-01   | CUST-0140     | Amit Mehta      | Wireless Mouse         | Accessories     | North    | Rahul Verma     |          3 |          799 |      2397 |   1233 |     1164 | UPI            | Delivered      |   2024 | 2024-01 | Yes          |          2397 |         1164 |
| ORD-100003 | 2024-01-01   | CUST-0499     | Ramesh Rao      | Water Purifier RO      | Home Appliances | South    | Lakshmi Iyer    |          1 |        12999 |     12999 |   9064 |     3935 | UPI            | Delivered      |   2024 | 2024-01 | Yes          |         12999 |         3935 |
| ORD-100004 | 2024-01-01   | CUST-0248     | Rohan Kapoor    | Laptop Backpack        | Accessories     | South    | Lakshmi Iyer    |          1 |         1499 |      1499 |    658 |      841 | Net Banking    | Delivered      |   2024 | 2024-01 | Yes          |          1499 |          841 |
| ORD-100005 | 2024-01-01   | CUST-0592     | Nisha Banerjee  | Desk Organizer         | Office Supplies | South    | Karthik Reddy   |          2 |          599 |      1198 |    568 |      630 | Debit Card     | Delivered      |   2024 | 2024-01 | Yes          |          1198 |          630 |
| ORD-100006 | 2024-01-01   | CUST-0255     | Suresh Reddy    | Laptop ProBook 14      | Electronics     | South    | Karthik Reddy   |          1 |        49499 |     49499 |  47028 |     2471 | Net Banking    | Delivered      |   2024 | 2024-01 | Yes          |         49499 |         2471 |
| ORD-100007 | 2024-01-01   | CUST-0478     | Divya Joshi     | Mixer Grinder 750W     | Home Appliances | East     | Ananya Banerjee |          1 |         3499 |      3499 |   2216 |     1283 | Credit Card    | Delivered      |   2024 | 2024-01 | Yes          |          3499 |         1283 |
| ORD-100008 | 2024-01-01   | CUST-0284     | Priya Shah      | Air Fryer 4L           | Home Appliances | South    | Lakshmi Iyer    |          1 |         6499 |      6499 |   4166 |     2333 | UPI            | Delivered      |   2024 | 2024-01 | Yes          |          6499 |         2333 |
| ORD-100009 | 2024-01-01   | CUST-0099     | Pooja Malhotra  | Ergonomic Office Chair | Furniture       | North    | Priya Sharma    |          1 |         7499 |      7499 |   4522 |     2977 | Debit Card     | Delivered      |   2024 | 2024-01 | Yes          |          7499 |         2977 |
| ORD-100010 | 2024-01-01   | CUST-0194     | Ritu Verma      | Wireless Mouse         | Accessories     | West     | Kunal Shah      |          2 |          799 |      1598 |    792 |      806 | Debit Card     | Delivered      |   2024 | 2024-01 | Yes          |          1598 |          806 |

## Q2. Total records, date range and number of unique customers  (02_select_where_groupby.sql)
Rows returned: 1

|   total_orders | first_order   | last_order   |   unique_customers |
|---------------:|:--------------|:-------------|-------------------:|
|           5500 | 2024-01-01    | 2025-12-31   |                575 |

## Q3. WHERE + AND: Delivered Electronics orders in the West region above Rs 50,000  (02_select_where_groupby.sql)
Rows returned: 23

| order_id   | order_date   | product_name      |   quantity |   revenue | salesperson   |
|:-----------|:-------------|:------------------|-----------:|----------:|:--------------|
| ORD-101000 | 2024-06-02   | Laptop ProBook 14 |          2 |    109998 | Rohan Mehta   |
| ORD-101025 | 2024-06-06   | Laptop ProBook 14 |          2 |    109998 | Rohan Mehta   |
| ORD-101628 | 2024-09-07   | Laptop ProBook 14 |          2 |     98998 | Rohan Mehta   |
| ORD-101809 | 2024-10-04   | Laptop ProBook 14 |          2 |     98998 | Kunal Shah    |
| ORD-103179 | 2025-03-22   | 4K Smart TV 43in  |          2 |     57998 | Rohan Mehta   |
| ORD-102445 | 2024-12-16   | 4K Smart TV 43in  |          2 |     55098 | Neha Patil    |
| ORD-100050 | 2024-01-08   | Laptop ProBook 14 |          1 |     54999 | Rohan Mehta   |
| ORD-101504 | 2024-08-22   | Laptop ProBook 14 |          1 |     54999 | Rohan Mehta   |
| ORD-102092 | 2024-11-02   | Laptop ProBook 14 |          1 |     54999 | Neha Patil    |
| ORD-102344 | 2024-12-03   | Laptop ProBook 14 |          1 |     54999 | Rohan Mehta   |
| ORD-102380 | 2024-12-08   | Laptop ProBook 14 |          1 |     54999 | Rohan Mehta   |
| ORD-102571 | 2024-12-30   | Laptop ProBook 14 |          1 |     54999 | Rohan Mehta   |

## Q4. WHERE with IN / BETWEEN / LIKE: Q4-2025 UPI or Wallet orders for products starting with 'Smart'  (02_select_where_groupby.sql)
Rows returned: 27

| order_id   | order_date   | product_name    | payment_mode   |   revenue |
|:-----------|:-------------|:----------------|:---------------|----------:|
| ORD-104679 | 2025-10-06   | Smartphone X1   | UPI            |     34198 |
| ORD-104692 | 2025-10-08   | Smart Watch Fit | UPI            |      9998 |
| ORD-104696 | 2025-10-08   | Smart Watch Fit | UPI            |      9998 |
| ORD-104711 | 2025-10-10   | Smartphone X1   | UPI            |     18999 |
| ORD-104745 | 2025-10-12   | Smart Watch Fit | UPI            |      4999 |
| ORD-104797 | 2025-10-17   | Smart Watch Fit | UPI            |      8998 |
| ORD-104801 | 2025-10-17   | Smart Watch Fit | UPI            |      4999 |
| ORD-104884 | 2025-10-25   | Smartphone X1   | UPI            |     18049 |
| ORD-104885 | 2025-10-25   | Smartphone X1   | UPI            |     18999 |
| ORD-104930 | 2025-10-28   | Smart Watch Fit | UPI            |      4999 |
| ORD-104958 | 2025-10-31   | Smart Watch Fit | UPI            |      9998 |
| ORD-104983 | 2025-11-03   | Smart Watch Fit | UPI            |      9498 |

## Q5. Order status summary (count, value, % of orders)  (02_select_where_groupby.sql)
Rows returned: 4

| order_status   |   orders |   booked_value |   pct_of_orders |
|:---------------|---------:|---------------:|----------------:|
| Delivered      |     4844 |       30836527 |           88.07 |
| Cancelled      |      333 |        2091306 |            6.05 |
| Returned       |      263 |        2335275 |            4.78 |
| Shipped        |       60 |         395834 |            1.09 |

## Q6. GROUP BY: Category-wise revenue, profit and margin (valid sales only)  (02_select_where_groupby.sql)
Rows returned: 5

| category        |   orders |   revenue |   profit |   margin_pct |
|:----------------|---------:|----------:|---------:|-------------:|
| Electronics     |      929 |  12475182 |  2692874 |        21.59 |
| Home Appliances |      752 |   5844366 |  1696656 |        29.03 |
| Accessories     |     1622 |   5686098 |  3205087 |        56.37 |
| Furniture       |      405 |   3887217 |  1419895 |        36.53 |
| Office Supplies |     1196 |   3339498 |  1221391 |        36.57 |

## Q7. HAVING: Customers with at least 15 valid orders (loyal customers)  (02_select_where_groupby.sql)
Rows returned: 90

| customer_id   | customer_name     |   orders |   total_spent |
|:--------------|:------------------|---------:|--------------:|
| CUST-0175     | Vijay Sharma      |       68 |        483410 |
| CUST-0453     | Shreya Nair       |       76 |        456303 |
| CUST-0182     | Suresh Menon      |       43 |        421117 |
| CUST-0032     | Sanjay Pandey     |       35 |        388698 |
| CUST-0045     | Arjun Chopra      |       52 |        388138 |
| CUST-0248     | Rohan Kapoor      |       58 |        359158 |
| CUST-0293     | Divya Nair        |       43 |        353653 |
| CUST-0031     | Suresh Chatterjee |       38 |        334241 |
| CUST-0003     | Sneha Menon       |       53 |        311297 |
| CUST-0497     | Ramesh Reddy      |       53 |        306127 |
| CUST-0125     | Meena Gupta       |       42 |        281712 |
| CUST-0534     | Kavita Agarwal    |       44 |        278463 |

## Q8. HAVING: Products whose margin is below 25% (candidates for price review)  (02_select_where_groupby.sql)
Rows returned: 5

| product_name       | category        |   revenue |   margin_pct |
|:-------------------|:----------------|----------:|-------------:|
| Laptop ProBook 14  | Electronics     |   3591433 |        12.83 |
| Smartphone X1      | Electronics     |   3059784 |        15.46 |
| 4K Smart TV 43in   | Electronics     |   2564959 |        17.51 |
| Laser Printer      | Office Supplies |    833056 |        19.01 |
| Microwave Oven 25L | Home Appliances |   1385856 |        23.22 |

## Q9. Payment-mode analysis with cancellation rate  (02_select_where_groupby.sql)
Rows returned: 7

| payment_mode   |   orders |   cancelled |   cancel_rate_pct |
|:---------------|---------:|------------:|------------------:|
| COD            |      760 |          99 |             13.03 |
| Unknown        |       35 |           2 |              5.71 |
| UPI            |     2083 |         115 |              5.52 |
| Credit Card    |     1026 |          52 |              5.07 |
| Debit Card     |      745 |          31 |              4.16 |
| Net Banking    |      544 |          22 |              4.04 |
| Wallet         |      307 |          12 |              3.91 |

## Q10. INNER JOIN sales + products: revenue vs list price (how much discount was given?)  (03_joins_subqueries.sql)
Rows returned: 10

| product_name               |   list_price |   avg_selling_price |   avg_discount_pct |
|:---------------------------|-------------:|--------------------:|-------------------:|
| A4 Printer Paper (5 Reams) |          349 |                 336 |               3.67 |
| Microwave Oven 25L         |         9999 |                9638 |               3.61 |
| USB-C Cable                |          399 |                 386 |               3.34 |
| Smart Watch Fit            |         4999 |                4833 |               3.32 |
| Laser Printer              |        12499 |               12086 |               3.31 |
| Water Purifier RO          |        12999 |               12572 |               3.28 |
| Bluetooth Speaker          |         1999 |                1934 |               3.27 |
| Phone Case                 |          499 |                 483 |               3.25 |
| Desk Organizer             |          599 |                 580 |               3.16 |
| Spiral Notebook Pack       |          299 |                 290 |               3.13 |

## Q11. JOIN sales + salespeople: target vs actual (achievement %)  (03_joins_subqueries.sql)
Rows returned: 12

| salesperson_name   | region   |   target |   actual_revenue |   achievement_pct | status          |
|:-------------------|:---------|---------:|-----------------:|------------------:|:----------------|
| Ananya Banerjee    | East     |  1800000 |          1959407 |             108.9 | Target Achieved |
| Arjun Nair         | South    |  1900000 |          2019096 |             106.3 | Target Achieved |
| Priya Sharma       | North    |  3000000 |          3078564 |             102.6 | Target Achieved |
| Pooja Joshi        | Central  |  1100000 |          1115082 |             101.4 | Target Achieved |
| Vikram Singh       | Central  |  1600000 |          1619159 |             101.2 | Target Achieved |
| Kunal Shah         | West     |  2100000 |          2114291 |             100.7 | Target Achieved |
| Lakshmi Iyer       | South    |  2500000 |          2492003 |              99.7 | Near Target     |
| Sourav Das         | East     |  2300000 |          2216281 |              96.4 | Near Target     |
| Rohan Mehta        | West     |  4500000 |          4333439 |              96.3 | Near Target     |
| Neha Patil         | West     |  3200000 |          2958699 |              92.5 | Near Target     |
| Rahul Verma        | North    |  4100000 |          3791008 |              92.5 | Near Target     |
| Karthik Reddy      | South    |  3900000 |          3535332 |              90.6 | Near Target     |

## Q12. LEFT JOIN: customers who never placed a valid order (should be listed even with 0 orders)  (03_joins_subqueries.sql)
Rows returned: 30

| customer_id   | customer_name   | region   |   valid_orders |
|:--------------|:----------------|:---------|---------------:|
| CUST-0007     | Sanjay Rao      | West     |              0 |
| CUST-0022     | Anita Joshi     | South    |              0 |
| CUST-0033     | Suresh Sharma   | South    |              0 |
| CUST-0050     | Priya Sharma    | North    |              0 |
| CUST-0051     | Meena Mehta     | North    |              0 |
| CUST-0119     | Deepak Malhotra | South    |              0 |
| CUST-0138     | Rekha Iyer      | South    |              0 |
| CUST-0142     | Ramesh Gupta    | East     |              0 |
| CUST-0145     | Arjun Joshi     | South    |              0 |
| CUST-0164     | Karan Singh     | North    |              0 |
| CUST-0199     | Sneha Agarwal   | North    |              0 |
| CUST-0203     | Arjun Menon     | East     |              0 |

## Q13. 3-table JOIN: region x category revenue, adding product cost info  (03_joins_subqueries.sql)
Rows returned: 25

| region   | category        |   orders |   revenue |   profit |
|:---------|:----------------|---------:|----------:|---------:|
| Central  | Electronics     |       92 |   1154899 |   263486 |
| Central  | Accessories     |      166 |    599707 |   340822 |
| Central  | Home Appliances |       47 |    410910 |   119348 |
| Central  | Furniture       |       30 |    305381 |   111896 |
| Central  | Office Supplies |      101 |    263344 |    97878 |
| East     | Electronics     |      134 |   1572477 |   371918 |
| East     | Home Appliances |      114 |    842093 |   252297 |
| East     | Accessories     |      207 |    719730 |   404543 |
| East     | Furniture       |       68 |    569684 |   213333 |
| East     | Office Supplies |      170 |    471704 |   174305 |
| North    | Electronics     |      203 |   2721129 |   589506 |
| North    | Home Appliances |      173 |   1390221 |   396904 |

## Q14. SUBQUERY in WHERE: orders bigger than the overall average order value  (03_joins_subqueries.sql)
Rows returned: 10

| order_id   | order_date   | product_name      |   revenue |
|:-----------|:-------------|:------------------|----------:|
| ORD-100181 | 2024-01-30   | Laptop ProBook 14 |    109998 |
| ORD-101000 | 2024-06-02   | Laptop ProBook 14 |    109998 |
| ORD-101025 | 2024-06-06   | Laptop ProBook 14 |    109998 |
| ORD-102731 | 2025-01-23   | Laptop ProBook 14 |    109998 |
| ORD-103723 | 2025-05-29   | Laptop ProBook 14 |    109998 |
| ORD-104170 | 2025-08-03   | Laptop ProBook 14 |    104498 |
| ORD-101628 | 2024-09-07   | Laptop ProBook 14 |     98998 |
| ORD-101809 | 2024-10-04   | Laptop ProBook 14 |     98998 |
| ORD-100677 | 2024-04-17   | 4K Smart TV 43in  |     57998 |
| ORD-101630 | 2024-09-07   | 4K Smart TV 43in  |     57998 |

## Q15. SUBQUERY in FROM: regions whose revenue is above the average region revenue  (03_joins_subqueries.sql)
Rows returned: 3

| region   |   revenue |
|:---------|----------:|
| West     |   9406429 |
| South    |   8046431 |
| North    |   6869572 |

## Q16. CORRELATED SUBQUERY: each region's best-selling product (by revenue)  (03_joins_subqueries.sql)
Rows returned: 5

| region   | product_name      |   revenue |
|:---------|:------------------|----------:|
| Central  | Smartphone X1     |    294484 |
| East     | Laptop ProBook 14 |    434492 |
| North    | Laptop ProBook 14 |    805735 |
| South    | Smartphone X1     |    871103 |
| West     | Laptop ProBook 14 |   1487722 |

## Q17. CTE: customers who spent more than the average customer  (03_joins_subqueries.sql)
Rows returned: 10

| customer_id   | customer_name     |   spent |
|:--------------|:------------------|--------:|
| CUST-0175     | Vijay Sharma      |  483410 |
| CUST-0453     | Shreya Nair       |  456303 |
| CUST-0182     | Suresh Menon      |  421117 |
| CUST-0032     | Sanjay Pandey     |  388698 |
| CUST-0045     | Arjun Chopra      |  388138 |
| CUST-0248     | Rohan Kapoor      |  359158 |
| CUST-0293     | Divya Nair        |  353653 |
| CUST-0031     | Suresh Chatterjee |  334241 |
| CUST-0003     | Sneha Menon       |  311297 |
| CUST-0497     | Ramesh Reddy      |  306127 |

## Q18. Headline KPIs  (04_business_analysis.sql)
Rows returned: 1

|   total_revenue |   total_profit |   total_orders |   total_customers |   avg_order_value |   profit_margin_pct |
|----------------:|---------------:|---------------:|------------------:|------------------:|--------------------:|
|     3.12324e+07 |    1.02359e+07 |           4904 |               570 |           6368.75 |               32.77 |

## Q19. Monthly revenue analysis with Month-over-Month growth (window function LAG)  (04_business_analysis.sql)
Rows returned: 24

| month   |   orders |   revenue |   profit |   margin_pct |   mom_growth_pct |
|:--------|---------:|----------:|---------:|-------------:|-----------------:|
| 2024-01 |      180 |   1261760 |   378089 |        29.97 |           nan    |
| 2024-02 |      149 |    984844 |   305720 |        31.04 |           -21.95 |
| 2024-03 |      179 |   1141385 |   372680 |        32.65 |            15.9  |
| 2024-04 |      178 |   1057058 |   370086 |        35.01 |            -7.39 |
| 2024-05 |      196 |   1095163 |   368658 |        33.66 |             3.6  |
| 2024-06 |      174 |   1102896 |   381265 |        34.57 |             0.71 |
| 2024-07 |      155 |    917306 |   323615 |        35.28 |           -16.83 |
| 2024-08 |      214 |   1255515 |   458231 |        36.5  |            36.87 |
| 2024-09 |      174 |   1185742 |   365622 |        30.83 |            -5.56 |
| 2024-10 |      262 |   1684318 |   556258 |        33.03 |            42.05 |
| 2024-11 |      225 |   1310342 |   445215 |        33.98 |           -22.2  |
| 2024-12 |      228 |   1508505 |   486232 |        32.23 |            15.12 |

## Q20. Year-on-year comparison by month number  (04_business_analysis.sql)
Rows returned: 12

|   month_no |   rev_2024 |   rev_2025 |   yoy_growth_pct |
|-----------:|-----------:|-----------:|-----------------:|
|         01 |    1261760 |    1117474 |            -11.4 |
|         02 |     984844 |    1454888 |             47.7 |
|         03 |    1141385 |    1171347 |              2.6 |
|         04 |    1057058 |    1518200 |             43.6 |
|         05 |    1095163 |    1416479 |             29.3 |
|         06 |    1102896 |    1052143 |             -4.6 |
|         07 |     917306 |    1275551 |             39.1 |
|         08 |    1255515 |    1662741 |             32.4 |
|         09 |    1185742 |    1412918 |             19.2 |
|         10 |    1684318 |    1636912 |             -2.8 |
|         11 |    1310342 |    1469566 |             12.2 |
|         12 |    1508505 |    1539308 |              2   |

## Q21. TOP 10 products by revenue  (04_business_analysis.sql)
Rows returned: 10

| product_name        | category        |   units_sold |   revenue |   profit |   margin_pct |   revenue_rank |
|:--------------------|:----------------|-------------:|----------:|---------:|-------------:|---------------:|
| Laptop ProBook 14   | Electronics     |           67 |   3591433 |   460743 |        12.83 |              1 |
| Smartphone X1       | Electronics     |          166 |   3059784 |   472965 |        15.46 |              2 |
| 4K Smart TV 43in    | Electronics     |           91 |   2564959 |   449138 |        17.51 |              3 |
| Air Fryer 4L        | Home Appliances |          244 |   1544806 |   495163 |        32.05 |              4 |
| Phone Case          | Accessories     |         3199 |   1544451 |  1065997 |        69.02 |              5 |
| Microwave Oven 25L  | Home Appliances |          144 |   1385856 |   321751 |        23.22 |              6 |
| USB-C Cable         | Accessories     |         3361 |   1295559 |   825548 |        63.72 |              7 |
| Water Purifier RO   | Home Appliances |          103 |   1295347 |   357907 |        27.63 |              8 |
| Smart Watch Fit     | Electronics     |          252 |   1220998 |   465646 |        38.14 |              9 |
| Power Bank 20000mAh | Accessories     |          691 |   1206479 |   461935 |        38.29 |             10 |

## Q22. Region-wise performance with share of total  (04_business_analysis.sql)
Rows returned: 5

| region   |   orders |   revenue |   profit |   margin_pct |   revenue_share_pct |   avg_order_value |
|:---------|---------:|----------:|---------:|-------------:|--------------------:|------------------:|
| West     |     1396 |   9406429 |  2955301 |        31.42 |               30.12 |              6738 |
| South    |     1307 |   8046431 |  2698420 |        33.54 |               25.76 |              6156 |
| North    |     1072 |   6869572 |  2232356 |        32.5  |               22    |              6408 |
| East     |      693 |   4175688 |  1416396 |        33.92 |               13.37 |              6026 |
| Central  |      436 |   2734241 |   933430 |        34.14 |                8.75 |              6271 |

## Q23. Profit analysis: category x margin with rank, and share of total profit  (04_business_analysis.sql)
Rows returned: 5

| category        |   profit |   share_of_profit_pct |   margin_pct |   margin_rank |
|:----------------|---------:|----------------------:|-------------:|--------------:|
| Accessories     |  3205087 |                 31.31 |        56.37 |             1 |
| Office Supplies |  1221391 |                 11.93 |        36.57 |             2 |
| Furniture       |  1419895 |                 13.87 |        36.53 |             3 |
| Home Appliances |  1696656 |                 16.58 |        29.03 |             4 |
| Electronics     |  2692874 |                 26.31 |        21.59 |             5 |

## Q24. Top 5 most profitable products, and the 5 least profitable  (04_business_analysis.sql)
Rows returned: 10

| product_name               |   profit |
|:---------------------------|---------:|
| Phone Case                 |  1065997 |
| USB-C Cable                |   825548 |
| Laptop Backpack            |   553125 |
| Air Fryer 4L               |   495163 |
| Smartphone X1              |   472965 |
| Laser Printer              |   158401 |
| Desk Organizer             |   190383 |
| Ceiling Fan 1200mm         |   234625 |
| A4 Printer Paper (5 Reams) |   238928 |
| Gel Pen Box (50)           |   260680 |

## Q25. Salesperson leaderboard with rank inside their own region  (04_business_analysis.sql)
Rows returned: 12

| salesperson     | region   |   orders |   revenue |   rank_in_region |   overall_rank |
|:----------------|:---------|---------:|----------:|-----------------:|---------------:|
| Rohan Mehta     | West     |      614 |   4333439 |                1 |              1 |
| Rahul Verma     | North    |      599 |   3791008 |                1 |              2 |
| Karthik Reddy   | South    |      548 |   3535332 |                1 |              3 |
| Priya Sharma    | North    |      473 |   3078564 |                2 |              4 |
| Neha Patil      | West     |      452 |   2958699 |                2 |              5 |
| Lakshmi Iyer    | South    |      418 |   2492003 |                2 |              6 |
| Sourav Das      | East     |      393 |   2216281 |                1 |              7 |
| Kunal Shah      | West     |      330 |   2114291 |                3 |              8 |
| Arjun Nair      | South    |      341 |   2019096 |                3 |              9 |
| Ananya Banerjee | East     |      300 |   1959407 |                2 |             10 |
| Vikram Singh    | Central  |      258 |   1619159 |                1 |             11 |
| Pooja Joshi     | Central  |      178 |   1115082 |                2 |             12 |

## Q26. Cancellation / return leakage by category (value lost)  (04_business_analysis.sql)
Rows returned: 5

| category        |   cancelled_value |   returned_value |   return_rate_pct |
|:----------------|------------------:|-----------------:|------------------:|
| Electronics     |            739160 |          1410160 |              8.46 |
| Furniture       |            377846 |           404673 |              8.02 |
| Accessories     |            344996 |           234855 |              3.8  |
| Home Appliances |            476775 |           200877 |              3.45 |
| Office Supplies |            152529 |            84710 |              2.7  |

## Q27. Running (cumulative) revenue by month  (04_business_analysis.sql)
Rows returned: 24

| month   |   revenue |   cumulative_revenue |
|:--------|----------:|---------------------:|
| 2024-01 |   1261760 |              1261760 |
| 2024-02 |    984844 |              2246604 |
| 2024-03 |   1141385 |              3387989 |
| 2024-04 |   1057058 |              4445047 |
| 2024-05 |   1095163 |              5540210 |
| 2024-06 |   1102896 |              6643106 |
| 2024-07 |    917306 |              7560412 |
| 2024-08 |   1255515 |              8815927 |
| 2024-09 |   1185742 |             10001669 |
| 2024-10 |   1684318 |             11685987 |
| 2024-11 |   1310342 |             12996329 |
| 2024-12 |   1508505 |             14504834 |

## Q28. Data-quality check: any order where revenue <> quantity x unit_price, or profit <> revenue - cost? (expect 0 rows)  (04_business_analysis.sql)
Rows returned: 0

_(no rows - expected)_
