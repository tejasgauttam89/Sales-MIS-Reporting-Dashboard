-- =====================================================================
-- 03_joins_subqueries.sql  |  INNER / LEFT JOIN, multi-table JOIN, subqueries, CTE
-- =====================================================================

-- Q10. INNER JOIN sales + products: revenue vs list price (how much discount was given?)
SELECT s.product_name, p.list_price,
       ROUND(AVG(s.unit_price), 0) AS avg_selling_price,
       ROUND(100.0 * (p.list_price - AVG(s.unit_price)) / p.list_price, 2) AS avg_discount_pct
FROM sales s
INNER JOIN products p ON s.product_name = p.product_name
WHERE s.valid_sale = 'Yes'
GROUP BY s.product_name, p.list_price
ORDER BY avg_discount_pct DESC
LIMIT 10;

-- Q11. JOIN sales + salespeople: target vs actual (achievement %)
SELECT sp.salesperson_name, sp.region, sp.target,
       SUM(s.revenue) AS actual_revenue,
       ROUND(100.0 * SUM(s.revenue) / sp.target, 1) AS achievement_pct,
       CASE WHEN SUM(s.revenue) >= sp.target THEN 'Target Achieved'
            WHEN SUM(s.revenue) >= 0.9 * sp.target THEN 'Near Target'
            ELSE 'Below Target' END AS status
FROM salespeople sp
JOIN sales s ON s.salesperson = sp.salesperson_name AND s.valid_sale = 'Yes'
GROUP BY sp.salesperson_name, sp.region, sp.target
ORDER BY achievement_pct DESC;

-- Q12. LEFT JOIN: customers who never placed a valid order (should be listed even with 0 orders)
SELECT c.customer_id, c.customer_name, c.region, COUNT(s.order_id) AS valid_orders
FROM customers c
LEFT JOIN sales s ON s.customer_id = c.customer_id AND s.valid_sale = 'Yes'
GROUP BY c.customer_id, c.customer_name, c.region
HAVING COUNT(s.order_id) = 0;

-- Q13. 3-table JOIN: region x category revenue, adding product cost info
SELECT s.region, p.category, COUNT(*) AS orders, SUM(s.revenue) AS revenue, SUM(s.profit) AS profit
FROM sales s
JOIN products p    ON p.product_name = s.product_name
JOIN salespeople sp ON sp.salesperson_name = s.salesperson
WHERE s.valid_sale = 'Yes'
GROUP BY s.region, p.category
ORDER BY s.region, revenue DESC;

-- Q14. SUBQUERY in WHERE: orders bigger than the overall average order value
SELECT order_id, order_date, product_name, revenue
FROM sales
WHERE valid_sale = 'Yes' AND revenue > (SELECT AVG(revenue) FROM sales WHERE valid_sale = 'Yes')
ORDER BY revenue DESC
LIMIT 10;

-- Q15. SUBQUERY in FROM: regions whose revenue is above the average region revenue
SELECT region, revenue
FROM (SELECT region, SUM(revenue) AS revenue FROM sales WHERE valid_sale = 'Yes' GROUP BY region) AS r
WHERE revenue > (SELECT AVG(revenue)
                 FROM (SELECT SUM(revenue) AS revenue FROM sales WHERE valid_sale = 'Yes' GROUP BY region) AS x)
ORDER BY revenue DESC;

-- Q16. CORRELATED SUBQUERY: each region's best-selling product (by revenue)
SELECT region, product_name, revenue FROM (
    SELECT region, product_name, SUM(revenue) AS revenue
    FROM sales WHERE valid_sale = 'Yes' GROUP BY region, product_name
) t
WHERE revenue = (SELECT MAX(r2.revenue) FROM (
                    SELECT region, product_name, SUM(revenue) AS revenue
                    FROM sales WHERE valid_sale = 'Yes' GROUP BY region, product_name) r2
                 WHERE r2.region = t.region)
ORDER BY region;

-- Q17. CTE: customers who spent more than the average customer
WITH cust AS (
    SELECT customer_id, customer_name, SUM(revenue) AS spent
    FROM sales WHERE valid_sale = 'Yes' GROUP BY customer_id, customer_name
)
SELECT customer_id, customer_name, spent
FROM cust
WHERE spent > (SELECT AVG(spent) FROM cust)
ORDER BY spent DESC
LIMIT 10;
