# Business Insights - Sales MIS Project

_All numbers are auto-calculated by `02_clean_and_analyze.py` from `sales_cleaned.csv`. Valid sales = status not Cancelled/Returned._

1. **Overall business health** - Valid (non-cancelled, non-returned) sales over 24 months: 4,904 orders, ₹3.12 Cr revenue, ₹1.02 Cr profit, margin 32.77%, average order value ₹6,369.

2. **Year-on-year growth** - 2025 revenue (₹1.67 Cr) grew 15.3% over 2024 (₹1.45 Cr). Order count rose 11.9% and average order value rose 3.0%, so growth came from both more customers buying and bigger baskets.

3. **Festive-season spike** - Peak month is 2024-10 (₹16.84 L); weakest is 2024-07 (₹9.17 L). October + November alone contribute 19.5% of 2-year revenue (Diwali/festive buying) -> stock and staff planning must start by September.

4. **Regional concentration** - West is the #1 region with 30.1% of revenue; Central is the smallest with only 8.8%. Top two regions (West, South) together give 55.9% of sales.

5. **Category mix vs profitability** - Electronics brings the most revenue (39.9% share) but at 21.6% margin, whereas Accessories earns the best margin (56.4%) and Electronics the lowest (21.6%).

6. **Product concentration** - Top 5 products (Laptop ProBook 14, Smartphone X1, 4K Smart TV 43in, Air Fryer 4L, Phone Case) generate 39.3% of revenue. #1 is Laptop ProBook 14 alone at 11.5%. Losing stock of these would hurt the most.

7. **High-revenue but low-margin product** - Among the top-10 products by revenue, Laptop ProBook 14 has the thinnest margin (12.8%). Even a 2% price/cost improvement here would add about ₹71,829.

8. **Salesperson performance** - Rohan Mehta leads with ₹43.33 L; Pooja Joshi is last with ₹11.15 L (3.9x gap). 6 of 12 salespeople met their 2-year target; best achievement Ananya Banerjee (108.9%), lowest Karthik Reddy (90.6%).

9. **Revenue leakage (cancel + return)** - 6.05% of orders were cancelled and 4.78% returned, locking out ₹0.44 Cr of booked value. Electronics has the highest return rate (8.5%).

10. **Cash-on-Delivery risk** - COD orders are cancelled 13.0% of the time vs 4.9% for prepaid modes (2.6x higher). UPI is the most used mode with 39.6% of revenue -> nudge COD customers to UPI with a small discount.

11. **Discount impact** - 40.4% of valid orders were sold at a discount (5-10% off list). Their margin is 29.8% vs 34.5% for full-price orders, so discounts cost about ₹548,255 in profit. Check whether discounted orders actually sell more units before continuing blanket offers.

12. **Customer concentration & loyalty** - Top 10% customers (57) give 39.3% of revenue, and 88.4% of customers bought more than once. A loyalty / key-account programme for the top group is a low-cost way to protect revenue.

13. **High-value orders** - Only 1.2% of orders are worth ₹50,000+, yet they contribute 11.7% of revenue (mostly Laptop ProBook 14, 4K Smart TV 43in).
