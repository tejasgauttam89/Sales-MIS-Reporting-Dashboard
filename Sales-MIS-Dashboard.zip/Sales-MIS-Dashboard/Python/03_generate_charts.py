"""03_generate_charts.py -> PNG charts + a one-page dashboard image in Screenshots/ (built from the real cleaned data)."""
import os, json
import pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SS = f"{BASE}/Screenshots"; os.makedirs(SS, exist_ok=True)
df = pd.read_csv(f"{BASE}/Dataset/sales_cleaned.csv", parse_dates=["Order Date"]); v = df[df["Valid Sale"] == "Yes"]
k = json.load(open(f"{BASE}/Python/output/kpis.json"))
NAVY, TEAL, ORANGE, GREY = "#1F3864", "#2E75B6", "#ED7D31", "#7F7F7F"
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.spines.top": False, "axes.spines.right": False, "axes.titleweight": "bold", "axes.titlesize": 11, "axes.titlecolor": NAVY})
lakh = FuncFormatter(lambda x, _: f"₹{x/1e5:g}L")

def monthly(ax):
    m = v.groupby("Month").Revenue.sum(); ax.plot(range(len(m)), m.values, color=TEAL, lw=2.5, marker="o", ms=4)
    ax.fill_between(range(len(m)), m.values, alpha=.12, color=TEAL); ax.set_xticks(range(0, len(m), 2)); ax.set_xticklabels(m.index[::2], rotation=45, ha="right", fontsize=8)
    ax.yaxis.set_major_formatter(lakh); ax.set_title("Monthly Revenue Trend"); ax.grid(axis="y", alpha=.3)
def region(ax):
    r = v.groupby("Region").Revenue.sum().sort_values(); b = ax.barh(r.index, r.values, color=TEAL)
    ax.xaxis.set_major_formatter(lakh); ax.set_title("Region-wise Sales"); [ax.text(x.get_width(), x.get_y()+x.get_height()/2, f"  {100*x.get_width()/r.sum():.1f}%", va="center", fontsize=8) for x in b]
def category(ax):
    c = v.groupby("Category").Revenue.sum().sort_values(ascending=False)
    ax.pie(c.values, labels=c.index, autopct="%1.1f%%", startangle=90, wedgeprops=dict(width=.45, edgecolor="white"), colors=[NAVY, TEAL, "#9DC3E6", ORANGE, "#A5A5A5"], textprops={"fontsize": 8})
    ax.set_title("Category-wise Revenue")
def top10(ax):
    p = v.groupby("Product Name").Revenue.sum().sort_values().tail(10); ax.barh(p.index, p.values, color=NAVY); ax.xaxis.set_major_formatter(lakh); ax.set_title("Top 10 Products by Revenue"); ax.tick_params(axis="y", labelsize=8)
def sales(ax):
    s = v.groupby("Salesperson").Revenue.sum().sort_values(); ax.barh(s.index, s.values, color=[ORANGE if x == s.max() else TEAL for x in s.values]); ax.xaxis.set_major_formatter(lakh); ax.set_title("Salesperson Performance"); ax.tick_params(axis="y", labelsize=8)
def status(ax):
    s = df["Order Status"].value_counts().reindex(["Delivered", "Shipped", "Cancelled", "Returned"]); b = ax.bar(s.index, s.values, color=[TEAL, "#9DC3E6", ORANGE, "#C00000"])
    ax.set_title("Order Status Analysis"); [ax.text(x.get_x()+x.get_width()/2, x.get_height(), f"{int(x.get_height()):,}\n({100*x.get_height()/s.sum():.1f}%)", ha="center", va="bottom", fontsize=8) for x in b]; ax.set_ylim(0, s.max()*1.18)

panels = [("01_monthly_revenue_trend", monthly), ("02_region_wise_sales", region), ("03_category_revenue", category),
          ("04_top10_products", top10), ("05_salesperson_performance", sales), ("06_order_status", status)]
for name, fn in panels:
    f, ax = plt.subplots(figsize=(7, 4.2)); fn(ax); f.tight_layout(); f.savefig(f"{SS}/{name}.png", dpi=130); plt.close(f)

# ---- one-page dashboard ----
fig = plt.figure(figsize=(18, 10.5), facecolor="#F4F6FA")
fig.text(.02, .965, "Sales MIS Reporting & Business Performance Dashboard", fontsize=20, fontweight="bold", color=NAVY)
fig.text(.02, .935, "Jan 2024 - Dec 2025  |  Valid sales (excl. Cancelled & Returned)  |  Python-generated preview of the Power BI layout", fontsize=10, color=GREY)
cards = [("Total Revenue", f"₹{k['total_revenue']/1e7:.2f} Cr"), ("Total Profit", f"₹{k['total_profit']/1e7:.2f} Cr"), ("Total Orders", f"{k['total_orders']:,}"),
         ("Total Customers", f"{k['total_customers']:,}"), ("Avg Order Value", f"₹{k['avg_order_value']:,.0f}"), ("Profit Margin", f"{k['profit_margin_pct']:.1f}%")]
for i, (t, val) in enumerate(cards):
    ax = fig.add_axes([.02 + i*.162, .81, .15, .105]); ax.set_facecolor("white"); ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_color("#D9D9D9")
    ax.add_patch(plt.Rectangle((0, .92), 1, .08, transform=ax.transAxes, color=TEAL)); ax.text(.5, .58, val, ha="center", va="center", fontsize=22, fontweight="bold", color=NAVY, transform=ax.transAxes)
    ax.text(.5, .22, t, ha="center", va="center", fontsize=10.5, color="#404040", transform=ax.transAxes)
pos = [[.05, .45, .42, .30], [.56, .45, .19, .30], [.79, .45, .19, .30], [.33, .06, .25, .30], [.70, .06, .27, .30]]
fns = [monthly, region, category, top10, sales]
for p, fn in zip(pos, fns):
    ax = fig.add_axes(p); ax.set_facecolor("white"); fn(ax)
ax = fig.add_axes([.06, .06, .16, .30]); status(ax); ax.tick_params(labelsize=8)
fig.savefig(f"{SS}/00_dashboard_overview.png", dpi=110, facecolor=fig.get_facecolor()); print("charts saved")
