"""
01_generate_dataset.py
Creates realistic synthetic Indian e-commerce/retail sales data (5,500 unique orders, Jan-2024 to Dec-2025)
and a deliberately DIRTY raw file (duplicates, blanks, bad casing, mixed date formats) for cleaning practice.
Run:  python 01_generate_dataset.py
"""
import os
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DS = os.path.join(BASE, "Dataset")
os.makedirs(DS, exist_ok=True)

# ---------------- Master data ----------------
# (product, category, list price INR, cost ratio, popularity weight)
PRODUCTS = [
    ("Smartphone X1", "Electronics", 18999, 0.82, 5), ("Laptop ProBook 14", "Electronics", 54999, 0.85, 2),
    ("Wireless Earbuds", "Electronics", 2999, 0.55, 8), ("Smart Watch Fit", "Electronics", 4999, 0.60, 6),
    ("4K Smart TV 43in", "Electronics", 28999, 0.80, 2.5), ("Bluetooth Speaker", "Electronics", 1999, 0.58, 7),
    ("Air Fryer 4L", "Home Appliances", 6499, 0.66, 5), ("Mixer Grinder 750W", "Home Appliances", 3499, 0.64, 6),
    ("Microwave Oven 25L", "Home Appliances", 9999, 0.74, 3), ("Water Purifier RO", "Home Appliances", 12999, 0.70, 3),
    ("Ceiling Fan 1200mm", "Home Appliances", 2799, 0.68, 6),
    ("Ergonomic Office Chair", "Furniture", 7499, 0.62, 4), ("Study Desk", "Furniture", 5999, 0.60, 4),
    ("Bookshelf 5-Tier", "Furniture", 4499, 0.58, 4), ("Sofa 3-Seater", "Furniture", 21999, 0.66, 1.5),
    ("A4 Printer Paper (5 Reams)", "Office Supplies", 349, 0.70, 10), ("Gel Pen Box (50)", "Office Supplies", 199, 0.45, 9),
    ("Spiral Notebook Pack", "Office Supplies", 299, 0.50, 9), ("Desk Organizer", "Office Supplies", 599, 0.48, 7),
    ("Laser Printer", "Office Supplies", 12499, 0.78, 2),
    ("Laptop Backpack", "Accessories", 1499, 0.45, 8), ("USB-C Cable", "Accessories", 399, 0.35, 12),
    ("Power Bank 20000mAh", "Accessories", 1799, 0.60, 8), ("Phone Case", "Accessories", 499, 0.30, 11),
    ("Wireless Mouse", "Accessories", 799, 0.50, 9),
]
products = pd.DataFrame(PRODUCTS, columns=["product_name", "category", "list_price", "cost_ratio", "pop"])
products.insert(0, "product_id", [f"P{i:03d}" for i in range(1, len(products) + 1)])
products["unit_cost"] = (products.list_price * products.cost_ratio).round().astype(int)

REGION_W = {"North": .22, "South": .27, "East": .14, "West": .28, "Central": .09}
# salesperson, region, skill factor (higher = closes more orders)
SALES = [("Rahul Verma", "North", 1.2), ("Priya Sharma", "North", 0.9),
         ("Karthik Reddy", "South", 1.3), ("Lakshmi Iyer", "South", 1.0), ("Arjun Nair", "South", 0.8),
         ("Sourav Das", "East", 1.1), ("Ananya Banerjee", "East", 0.8),
         ("Rohan Mehta", "West", 1.3), ("Neha Patil", "West", 1.0), ("Kunal Shah", "West", 0.7),
         ("Vikram Singh", "Central", 1.1), ("Pooja Joshi", "Central", 0.8)]
sp = pd.DataFrame(SALES, columns=["salesperson_name", "region", "skill"])
sp.insert(0, "salesperson_id", [f"S{i:02d}" for i in range(1, 13)])

FIRST = ["Aarav","Vivaan","Aditya","Arjun","Rohan","Rahul","Amit","Suresh","Ramesh","Karan","Manish","Nikhil","Deepak","Sanjay","Vijay",
         "Priya","Anjali","Neha","Pooja","Sneha","Kavita","Divya","Meena","Sunita","Ritu","Swati","Shreya","Nisha","Anita","Rekha"]
LAST = ["Sharma","Verma","Gupta","Singh","Patel","Reddy","Nair","Iyer","Das","Banerjee","Mehta","Shah","Joshi","Kumar","Yadav",
        "Chopra","Malhotra","Kapoor","Agarwal","Mishra","Pandey","Rao","Menon","Chatterjee","Desai"]
N_CUST = 600
cust_region = rng.choice(list(REGION_W), size=N_CUST, p=list(REGION_W.values()))
customers = pd.DataFrame({
    "customer_id": [f"CUST-{i:04d}" for i in range(1, N_CUST + 1)],
    "customer_name": [f"{rng.choice(FIRST)} {rng.choice(LAST)}" for _ in range(N_CUST)],
    "region": cust_region,
})
cust_weight = rng.lognormal(0, 0.9, N_CUST)  # some customers buy far more often than others

# ---------------- Orders ----------------
N = 5500
days = pd.date_range("2024-01-01", "2025-12-31")
month_mult = {1: .90, 2: .85, 3: 1.0, 4: .95, 5: .95, 6: .85, 7: .85, 8: 1.0, 9: 1.0, 10: 1.35, 11: 1.30, 12: 1.10}
w = np.array([month_mult[d.month] * (1.0 if d.year == 2024 else 1.18) * (1.12 if d.dayofweek >= 5 else 1.0) for d in days])
dates = np.sort(rng.choice(days, size=N, p=w / w.sum()))

regions = rng.choice(list(REGION_W), size=N, p=list(REGION_W.values()))
pw = products["pop"].values / products["pop"].sum()
prod_idx = rng.choice(len(products), size=N, p=pw)

rows = []
for i in range(N):
    reg = regions[i]
    c = customers[customers.region == reg]
    cw = cust_weight[c.index]
    cust = c.iloc[rng.choice(len(c), p=cw / cw.sum())]
    p = products.iloc[prod_idx[i]]
    s = sp[sp.region == reg]
    seller = s.iloc[rng.choice(len(s), p=s.skill / s.skill.sum())]
    lp = p.list_price
    if lp < 500: qty = int(rng.integers(2, 16))
    elif lp < 2000: qty = int(rng.choice([1, 2, 3, 4, 5, 6], p=[.3, .25, .2, .12, .08, .05]))
    elif lp < 10000: qty = int(rng.choice([1, 2, 3], p=[.7, .22, .08]))
    else: qty = int(rng.choice([1, 2], p=[.9, .1]))
    price = int(round(lp * rng.choice([1, 1, 1, .95, .90])))
    unit_cost = int(round(lp * p.cost_ratio * rng.uniform(.97, 1.03)))
    revenue, cost = qty * price, qty * unit_cost
    pay = rng.choice(["UPI", "Credit Card", "Debit Card", "Net Banking", "COD", "Wallet"], p=[.38, .18, .14, .10, .14, .06])
    p_cancel = .05 + (.07 if pay == "COD" else 0)
    p_return = {"Electronics": .08, "Furniture": .06}.get(p.category, .035)
    in_transit = dates[i] >= np.datetime64("2025-12-21")
    p_ship = .5 if in_transit else 0.0
    status = rng.choice(["Delivered", "Shipped", "Cancelled", "Returned"],
                        p=[1 - p_cancel - p_return - p_ship, p_ship, p_cancel, p_return])
    rows.append([f"ORD-{100001 + i}", pd.Timestamp(dates[i]), cust.customer_id, cust.customer_name, p.product_name, p.category,
                 reg, seller.salesperson_name, qty, price, revenue, cost, revenue - cost, pay, status])

COLS = ["Order ID", "Order Date", "Customer ID", "Customer Name", "Product Name", "Category", "Region", "Salesperson",
        "Quantity", "Unit Price", "Revenue", "Cost", "Profit", "Payment Mode", "Order Status"]
clean = pd.DataFrame(rows, columns=COLS)

# salesperson targets = actual net revenue (full period) x random 0.92-1.10, rounded to 1 lakh
net = clean[~clean["Order Status"].isin(["Cancelled", "Returned"])].groupby("Salesperson")["Revenue"].sum()
sp["target"] = [int(round(net[n] * rng.uniform(.92, 1.10), -5)) for n in sp.salesperson_name]

# ---------------- Save master tables ----------------
products[["product_id", "product_name", "category", "list_price", "unit_cost"]].to_csv(f"{DS}/products.csv", index=False)
sp[["salesperson_id", "salesperson_name", "region", "target"]].to_csv(f"{DS}/salespeople.csv", index=False)
customers.to_csv(f"{DS}/customers.csv", index=False)

# ---------------- Make the RAW (dirty) file ----------------
raw = clean.copy()
raw["Order Date"] = raw["Order Date"].dt.strftime("%Y-%m-%d")
pick = lambda k: rng.choice(raw.index, size=k, replace=False)
d_idx = pick(100)
raw.loc[d_idx, "Order Date"] = clean.loc[d_idx, "Order Date"].dt.strftime("%d/%m/%Y")   # mixed date format
raw.loc[pick(45), "Region"] = np.nan                                                      # blank region
raw.loc[pick(35), "Payment Mode"] = np.nan                                                # blank payment mode
raw.loc[pick(25), "Customer Name"] = np.nan                                               # blank customer name
n_idx = pick(120)
raw.loc[n_idx, "Customer Name"] = raw.loc[n_idx, "Customer Name"].map(lambda x: f"  {str(x).upper()} " if pd.notna(x) else x)
r_idx = pick(80)
raw.loc[r_idx, "Region"] = raw.loc[r_idx, "Region"].map(lambda x: f" {x.lower()} " if pd.notna(x) else x)
raw.loc[pick(40), "Order Status"] = raw["Order Status"].str.upper()
dupes = raw.sample(60, random_state=1)                                                    # 60 exact duplicate rows
raw = pd.concat([raw, dupes]).sort_values("Order ID", kind="mergesort").reset_index(drop=True)
raw.to_csv(f"{DS}/sales_raw.csv", index=False)
print(f"Raw rows: {len(raw)} | Unique orders: {raw['Order ID'].nunique()} | Files saved in {DS}")
