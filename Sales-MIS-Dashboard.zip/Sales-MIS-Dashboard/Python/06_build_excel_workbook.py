"""
06_build_excel_workbook.py -> builds Excel/Sales_MIS_Report.xlsx (formula-driven; recalculates when data changes)
Sheets: README | KPI Dashboard | Raw Data | Cleaned Data | Product Master | Salesperson Master | Customer Master |
        Monthly Report | Region Report | Category Report | Product Report | Salesperson Report | Status & Payment | Lookup Tool | Pivot Guide
"""
import os
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.chart import LineChart, BarChart, PieChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.comments import Comment

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DS = f"{BASE}/Dataset"
raw = pd.read_csv(f"{DS}/sales_raw.csv", dtype=str, keep_default_na=False)
cl = pd.read_csv(f"{DS}/sales_cleaned.csv", parse_dates=["Order Date"])
prod = pd.read_csv(f"{DS}/products.csv"); sp = pd.read_csv(f"{DS}/salespeople.csv"); cu = pd.read_csv(f"{DS}/customers.csv")
N = len(cl); LAST = N + 1          # last data row in Cleaned Data

NAVY, TEAL, LIGHT, GREY = "1F3864", "2E75B6", "DDEBF7", "F2F2F2"
F = lambda **k: Font(name="Arial", size=k.pop("size", 10), **k)
HDR_FILL = PatternFill("solid", fgColor=NAVY)
thin = Side(style="thin", color="BFBFBF"); BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
INR, INR2, PCT, INT, DATE, MON = "₹#,##0", "₹#,##0.00", "0.0%", "#,##0", "dd-mmm-yyyy", "mmm-yyyy"

wb = Workbook()
def sheet(name, tab=None):
    ws = wb.create_sheet(name)
    if tab: ws.sheet_properties.tabColor = tab
    ws.sheet_view.showGridLines = False
    return ws
def header(ws, row, labels, col=1):
    for i, t in enumerate(labels):
        c = ws.cell(row=row, column=col + i, value=t)
        c.font = F(bold=True, color="FFFFFF"); c.fill = HDR_FILL; c.border = BORDER
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[row].height = 30
def title(ws, text, sub=None):
    ws["A1"] = text; ws["A1"].font = F(bold=True, size=16, color=NAVY)
    if sub: ws["A2"] = sub; ws["A2"].font = F(italic=True, color="595959")
def style_body(ws, r1, r2, c1, c2, fmts):
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            cell = ws.cell(row=r, column=c); cell.font = F(); cell.border = BORDER
            if fmts.get(c): cell.number_format = fmts[c]
def widths(ws, w):
    for i, x in enumerate(w, 1): ws.column_dimensions[L(i)].width = x
def total_row(ws, r, c1, c2):
    for c in range(c1, c2 + 1):
        x = ws.cell(row=r, column=c); x.font = F(bold=True); x.fill = PatternFill("solid", fgColor=LIGHT); x.border = BORDER
CD = lambda col: f"'Cleaned Data'!${col}$2:${col}${LAST}"      # absolute range helper for Cleaned Data

# ---------------- README ----------------
ws = wb.active; ws.title = "README"; ws.sheet_view.showGridLines = False; ws.sheet_properties.tabColor = NAVY
title(ws, "Sales MIS Reporting Workbook", "Prepared for management review | Period: Jan-2024 to Dec-2025 | Currency: INR")
lines = [
 ("HOW TO USE", ""), ("1.", "Start at 'KPI Dashboard' for headline numbers and charts."),
 ("2.", "'Raw Data' = untouched export (5,560 rows with duplicates, blanks, bad text). 'Cleaned Data' = 5,500 validated orders."),
 ("3.", "All report sheets are FORMULA driven (SUMIFS / COUNTIFS / INDEX-MATCH / IF / RANK). Add data to 'Cleaned Data' and extend the ranges to refresh."),
 ("4.", "'Lookup Tool' - type any Order ID in the yellow cell to fetch full order details (VLOOKUP + INDEX/MATCH)."),
 ("5.", "'Pivot Guide' - step-by-step to build real PivotTables from the table 'tblSales' (Insert > PivotTable)."),
 ("", ""), ("BUSINESS RULES", ""),
 ("•", "Valid Sale = Order Status is NOT Cancelled / Returned. Revenue, profit, orders, customers in reports use VALID sales only."),
 ("•", "Revenue = Quantity x Unit Price.  Profit = Revenue - Cost.  Profit Margin = Profit / Revenue.  AOV = Net Revenue / Valid Orders."),
 ("•", "Salesperson targets are 2-year revenue targets (synthetic) stored in 'Salesperson Master' (blue = input values)."),
 ("", ""), ("COLOUR CODE", ""),
 ("Blue text", "Hard-coded input (e.g. targets, thresholds)."), ("Black text", "Formula / calculated value."),
 ("Yellow cell", "Cell you are expected to type in."),
 ("", ""), ("NOTE", "XLOOKUP equivalent (Excel 365):  =XLOOKUP(B4,'Cleaned Data'!A:A,'Cleaned Data'!E:E,\"Not found\")  - this file uses INDEX/MATCH which works in every Excel version."),
]
for i, (a, b) in enumerate(lines, 4):
    ws.cell(row=i, column=1, value=a).font = F(bold=True, color=TEAL if b == "" else "000000")
    ws.cell(row=i, column=2, value=b).font = F()
widths(ws, [14, 130])

# ---------------- Raw Data (as imported; all text) ----------------
wr = sheet("Raw Data", "7F7F7F")
for j, c in enumerate(raw.columns, 1): wr.cell(row=1, column=j, value=c)
for i, row in enumerate(raw.itertuples(index=False), 2):
    for j, v in enumerate(row, 1):
        if v != "":
            wr.cell(row=i, column=j, value=int(v) if raw.columns[j-1] in ["Quantity","Unit Price","Revenue","Cost","Profit"] else v)
header(wr, 1, list(raw.columns)); wr.freeze_panes = "A2"; wr.auto_filter.ref = f"A1:O{len(raw)+1}"
widths(wr, [13, 12, 12, 22, 26, 16, 10, 16, 9, 10, 11, 11, 11, 13, 13])
wr.cell(row=1, column=17, value="Raw export as received - contains duplicates, blanks, mixed date formats and inconsistent text. Do NOT edit.").font = F(italic=True, color="C00000")

# ---------------- Masters ----------------
wp = sheet("Product Master", "A6A6A6")
header(wp, 1, ["Product ID", "Product Name", "Category", "List Price", "Unit Cost", "Std. Margin %"])
for i, r in enumerate(prod.itertuples(index=False), 2):
    for j, v in enumerate(r, 1): wp.cell(row=i, column=j, value=v)
    wp.cell(row=i, column=6, value=f"=IF(D{i}=0,0,(D{i}-E{i})/D{i})")
style_body(wp, 2, len(prod) + 1, 1, 6, {4: INR, 5: INR, 6: PCT}); widths(wp, [11, 28, 18, 12, 12, 14]); wp.freeze_panes = "A2"
for i in range(2, len(prod) + 2):
    for j in (4, 5): wp.cell(row=i, column=j).font = F(color="0000FF")
PM_LAST = len(prod) + 1

wsm = sheet("Salesperson Master", "A6A6A6")
header(wsm, 1, ["Salesperson ID", "Salesperson", "Region", "2-Year Target"])
for i, r in enumerate(sp.itertuples(index=False), 2):
    for j, v in enumerate(r, 1): wsm.cell(row=i, column=j, value=v)
style_body(wsm, 2, len(sp) + 1, 1, 4, {4: INR})
for i in range(2, len(sp) + 2): wsm.cell(row=i, column=4).font = F(color="0000FF")
widths(wsm, [14, 20, 12, 16]); SM_LAST = len(sp) + 1
wsm["F1"] = "Targets are synthetic assumptions (blue = input)."; wsm["F1"].font = F(italic=True, color="595959")

# ---------------- Cleaned Data ----------------
wc = sheet("Cleaned Data", "70AD47")
heads = ["Order ID", "Order Date", "Customer ID", "Customer Name", "Product Name", "Category", "Region", "Salesperson", "Quantity",
         "Unit Price", "Revenue", "Cost", "Profit", "Payment Mode", "Order Status", "Month", "Year", "Valid Sale", "Net Revenue",
         "Net Profit", "Order Value Band"]
for j, h in enumerate(heads, 1): wc.cell(row=1, column=j, value=h)
for i, r in enumerate(cl.itertuples(index=False), 2):
    r = r._asdict() if hasattr(r, "_asdict") else r
    wc.cell(row=i, column=1, value=cl.iat[i-2, 0]); wc.cell(row=i, column=2, value=cl.iat[i-2, 1].to_pydatetime())
    wc.cell(row=i, column=3, value=cl["Customer ID"].iat[i-2]); wc.cell(row=i, column=4, value=cl["Customer Name"].iat[i-2])
    wc.cell(row=i, column=5, value=cl["Product Name"].iat[i-2])
    wc.cell(row=i, column=6, value=f"=VLOOKUP(E{i},'Product Master'!$B$2:$C${PM_LAST},2,FALSE)")        # Category via VLOOKUP
    wc.cell(row=i, column=7, value=cl["Region"].iat[i-2]); wc.cell(row=i, column=8, value=cl["Salesperson"].iat[i-2])
    wc.cell(row=i, column=9, value=int(cl["Quantity"].iat[i-2])); wc.cell(row=i, column=10, value=int(cl["Unit Price"].iat[i-2]))
    wc.cell(row=i, column=11, value=f"=I{i}*J{i}")                                                     # Revenue
    wc.cell(row=i, column=12, value=int(cl["Cost"].iat[i-2]))
    wc.cell(row=i, column=13, value=f"=K{i}-L{i}")                                                     # Profit
    wc.cell(row=i, column=14, value=cl["Payment Mode"].iat[i-2]); wc.cell(row=i, column=15, value=cl["Order Status"].iat[i-2])
    wc.cell(row=i, column=16, value=f"=DATE(YEAR(B{i}),MONTH(B{i}),1)")
    wc.cell(row=i, column=17, value=f"=YEAR(B{i})")
    wc.cell(row=i, column=18, value=f'=IF(OR(O{i}="Cancelled",O{i}="Returned"),"No","Yes")')
    wc.cell(row=i, column=19, value=f'=IF(R{i}="Yes",K{i},0)')
    wc.cell(row=i, column=20, value=f'=IF(R{i}="Yes",M{i},0)')
    wc.cell(row=i, column=21, value=f'=IF(K{i}>=50000,"High",IF(K{i}>=15000,"Medium","Low"))')
fm = {2: DATE, 10: INR, 11: INR, 12: INR, 13: INR, 16: MON, 19: INR, 20: INR}
for r in range(2, LAST + 1):
    for c in range(1, 22):
        cell = wc.cell(row=r, column=c); cell.font = F()
        if c in fm: cell.number_format = fm[c]
header(wc, 1, heads); wc.freeze_panes = "B2"
tbl = Table(displayName="tblSales", ref=f"A1:U{LAST}"); tbl.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
wc.add_table(tbl)
widths(wc, [13, 12, 12, 22, 26, 16, 10, 16, 9, 11, 12, 12, 12, 13, 13, 11, 7, 9, 12, 12, 11])
wc["F1"].comment = Comment("Category is fetched with VLOOKUP from 'Product Master'.", "MIS")

# ---------------- Monthly Report ----------------
wm = sheet("Monthly Report", TEAL); title(wm, "Monthly Sales Report", "SUMIFS / COUNTIFS on 'Cleaned Data' (valid sales only)")
header(wm, 4, ["Month", "Valid Orders", "Net Revenue", "Net Profit", "Profit Margin %", "Avg Order Value", "MoM Growth %", "Trend"])
months = pd.period_range("2024-01", "2025-12", freq="M")
for k, p in enumerate(months):
    r = 5 + k
    wm.cell(row=r, column=1, value=p.to_timestamp().to_pydatetime())
    wm.cell(row=r, column=2, value=f'=COUNTIFS({CD("P")},A{r},{CD("R")},"Yes")')
    wm.cell(row=r, column=3, value=f'=SUMIFS({CD("S")},{CD("P")},A{r})')
    wm.cell(row=r, column=4, value=f'=SUMIFS({CD("T")},{CD("P")},A{r})')
    wm.cell(row=r, column=5, value=f"=IF(C{r}=0,0,D{r}/C{r})")
    wm.cell(row=r, column=6, value=f"=IF(B{r}=0,0,C{r}/B{r})")
    wm.cell(row=r, column=7, value="n/a" if k == 0 else f"=IF(C{r-1}=0,0,C{r}/C{r-1}-1)")
    wm.cell(row=r, column=8, value="-" if k == 0 else f'=IF(G{r}>0,"▲ Up",IF(G{r}<0,"▼ Down","= Flat"))')
M1, M2 = 5, 4 + len(months); MT = M2 + 1
wm.cell(row=MT, column=1, value="TOTAL")
wm.cell(row=MT, column=2, value=f"=SUM(B{M1}:B{M2})"); wm.cell(row=MT, column=3, value=f"=SUM(C{M1}:C{M2})"); wm.cell(row=MT, column=4, value=f"=SUM(D{M1}:D{M2})")
wm.cell(row=MT, column=5, value=f"=IF(C{MT}=0,0,D{MT}/C{MT})"); wm.cell(row=MT, column=6, value=f"=IF(B{MT}=0,0,C{MT}/B{MT})")
style_body(wm, M1, MT, 1, 8, {1: MON, 2: INT, 3: INR, 4: INR, 5: PCT, 6: INR, 7: PCT}); total_row(wm, MT, 1, 8); widths(wm, [12, 13, 15, 15, 14, 15, 14, 11])
wm.freeze_panes = "A5"
ch = LineChart(); ch.title = "Monthly Net Revenue Trend"; ch.height, ch.width = 8.5, 20
ch.add_data(Reference(wm, min_col=3, min_row=4, max_row=M2), titles_from_data=True)
ch.set_categories(Reference(wm, min_col=1, min_row=M1, max_row=M2)); ch.y_axis.title = "Revenue (₹)"; ch.y_axis.numFmt = "#,##0"; ch.x_axis.number_format = "mmm-yy"
ch.roundedCorners = False; ch.legend = None; ch.x_axis.delete = False; ch.y_axis.delete = False; ch.title.overlay = False
ch.series[0].graphicalProperties.line.solidFill = TEAL; ch.series[0].graphicalProperties.line.width = 28000
wm.add_chart(ch, "J4"); MONTH_CHART_REF = (wm, M1, M2)

# ---------------- generic dimension report ----------------
def dim_report(name, ttl, dimcol, items, label, extra_units=False):
    w = sheet(name, TEAL); title(w, ttl, "SUMIFS / COUNTIFS on 'Cleaned Data' (valid sales only)")
    hd = [label, "Valid Orders", "Units Sold", "Net Revenue", "Net Profit", "Profit Margin %", "Revenue Share %", "Avg Order Value", "Revenue Rank"]
    header(w, 4, hd)
    for k, it in enumerate(items):
        r = 5 + k; w.cell(row=r, column=1, value=it)
        w.cell(row=r, column=2, value=f'=COUNTIFS({CD(dimcol)},A{r},{CD("R")},"Yes")')
        w.cell(row=r, column=3, value=f'=SUMIFS({CD("I")},{CD(dimcol)},A{r},{CD("R")},"Yes")')
        w.cell(row=r, column=4, value=f'=SUMIFS({CD("S")},{CD(dimcol)},A{r})')
        w.cell(row=r, column=5, value=f'=SUMIFS({CD("T")},{CD(dimcol)},A{r})')
        w.cell(row=r, column=6, value=f"=IF(D{r}=0,0,E{r}/D{r})")
        w.cell(row=r, column=7, value=f"=IF($D${5+len(items)}=0,0,D{r}/$D${5+len(items)})")
        w.cell(row=r, column=8, value=f"=IF(B{r}=0,0,D{r}/B{r})")
        w.cell(row=r, column=9, value=f"=RANK(D{r},$D$5:$D${4+len(items)})")
    t = 5 + len(items); w.cell(row=t, column=1, value="TOTAL")
    for c in (2, 3, 4, 5): w.cell(row=t, column=c, value=f"=SUM({L(c)}5:{L(c)}{t-1})")
    w.cell(row=t, column=6, value=f"=IF(D{t}=0,0,E{t}/D{t})"); w.cell(row=t, column=7, value=f"=SUM(G5:G{t-1})"); w.cell(row=t, column=8, value=f"=IF(B{t}=0,0,D{t}/B{t})")
    style_body(w, 5, t, 1, 9, {2: INT, 3: INT, 4: INR, 5: INR, 6: PCT, 7: PCT, 8: INR, 9: "0"}); total_row(w, t, 1, 9)
    w.freeze_panes = "B5"; return w, t

regions = ["North", "South", "East", "West", "Central"]
wrg, RT = dim_report("Region Report", "Region-wise Sales Report", "G", regions, "Region")
bc = BarChart(); bc.type = "col"; bc.title = "Net Revenue by Region"; bc.height, bc.width = 8, 14
bc.add_data(Reference(wrg, min_col=4, min_row=4, max_row=4 + len(regions)), titles_from_data=True); bc.set_categories(Reference(wrg, min_col=1, min_row=5, max_row=4 + len(regions)))
bc.legend = None; bc.roundedCorners = False; bc.x_axis.delete = False; bc.y_axis.delete = False; bc.title.overlay = False; bc.y_axis.numFmt = "#,##0"
bc.series[0].graphicalProperties.solidFill = TEAL; wrg.add_chart(bc, "A13"); widths(wrg, [14, 13, 12, 15, 15, 14, 14, 15, 12])

cats = ["Electronics", "Home Appliances", "Furniture", "Office Supplies", "Accessories"]
wct, CT = dim_report("Category Report", "Category-wise Sales Report", "F", cats, "Category")
pc = PieChart(); pc.title = "Revenue Share by Category"; pc.height, pc.width = 8, 12
pc.add_data(Reference(wct, min_col=4, min_row=4, max_row=4 + len(cats)), titles_from_data=True); pc.set_categories(Reference(wct, min_col=1, min_row=5, max_row=4 + len(cats)))
pc.roundedCorners = False; pc.legend.overlay = False; pc.title.overlay = False
pc.dataLabels = DataLabelList(); pc.dataLabels.showPercent = True; pc.dataLabels.showVal = False; pc.dataLabels.showCatName = False; pc.dataLabels.showSerName = False; pc.dataLabels.showLegendKey = False
wct.add_chart(pc, "A13"); widths(wct, [18, 13, 12, 15, 15, 14, 14, 15, 12])

# ---------------- Product Report ----------------
wpr, PT = dim_report("Product Report", "Product Performance Report", "E", list(prod.product_name), "Product")
wpr.cell(row=4, column=10, value="Category"); wpr.cell(row=4, column=11, value="Margin Flag"); wpr.cell(row=4, column=12, value="Performance Tier")
header(wpr, 4, ["Product", "Valid Orders", "Units Sold", "Net Revenue", "Net Profit", "Profit Margin %", "Revenue Share %", "Avg Order Value", "Revenue Rank", "Category", "Margin Flag", "Performance Tier"])
for r in range(5, PT):
    wpr.cell(row=r, column=10, value=f"=INDEX('Product Master'!$C$2:$C${PM_LAST},MATCH(A{r},'Product Master'!$B$2:$B${PM_LAST},0))")
    wpr.cell(row=r, column=11, value=f'=IF(F{r}<0.25,"Low Margin",IF(F{r}>=0.4,"High Margin","Healthy"))')
    wpr.cell(row=r, column=12, value=f'=IF(I{r}<=5,"Top 5",IF(I{r}<=15,"Mid Performer","Bottom 10"))')
    for c in (10, 11, 12): wpr.cell(row=r, column=c).font = F(); wpr.cell(row=r, column=c).border = BORDER
total_row(wpr, PT, 10, 12)
wpr["A" + str(PT + 2)] = "Thresholds (editable in formulas): Low Margin < 25%, High Margin >= 40%. Tiers by revenue rank: Top 5, Mid 6-15, Bottom 16-25."; wpr["A" + str(PT + 2)].font = F(italic=True, color="595959")
widths(wpr, [28, 13, 12, 15, 15, 14, 14, 15, 12, 18, 14, 16])
# Top-10 chart helper table (ranked with INDEX/MATCH + LARGE so it re-sorts automatically)
wpr.cell(row=4, column=14, value="Top 10 (auto-sorted)").font = F(bold=True, color=NAVY)
header(wpr, 5, ["Rank", "Product", "Net Revenue"], col=14)
for k in range(10):
    r = 6 + k
    wpr.cell(row=r, column=14, value=k + 1)
    wpr.cell(row=r, column=16, value=f"=LARGE($D$5:$D${PT-1},N{r})")
    wpr.cell(row=r, column=15, value=f"=INDEX($A$5:$A${PT-1},MATCH(P{r},$D$5:$D${PT-1},0))")
style_body(wpr, 6, 15, 14, 16, {16: INR}); widths(wpr, [28, 13, 12, 15, 15, 14, 14, 15, 12, 18, 14, 16, 3, 7, 28, 15])
tc = BarChart(); tc.type = "bar"; tc.title = "Top 10 Products by Net Revenue"; tc.height, tc.width = 9, 16
tc.add_data(Reference(wpr, min_col=16, min_row=5, max_row=15), titles_from_data=True); tc.set_categories(Reference(wpr, min_col=15, min_row=6, max_row=15))
tc.legend = None; tc.roundedCorners = False; tc.x_axis.delete = False; tc.y_axis.delete = False; tc.title.overlay = False; tc.x_axis.scaling.orientation = "maxMin"; tc.y_axis.numFmt = "#,##0"
tc.series[0].graphicalProperties.solidFill = NAVY; wpr.add_chart(tc, "N18")

# ---------------- Salesperson Report ----------------
wsr = sheet("Salesperson Report", TEAL); title(wsr, "Salesperson Performance vs Target", "Target is the 2-year revenue target from 'Salesperson Master'")
header(wsr, 4, ["Salesperson", "Region", "Valid Orders", "Net Revenue", "Net Profit", "Profit Margin %", "2-Year Target", "Achievement %", "Status", "Rank"])
for k, name in enumerate(sp.salesperson_name):
    r = 5 + k; wsr.cell(row=r, column=1, value=name)
    wsr.cell(row=r, column=2, value=f"=INDEX('Salesperson Master'!$C$2:$C${SM_LAST},MATCH(A{r},'Salesperson Master'!$B$2:$B${SM_LAST},0))")
    wsr.cell(row=r, column=3, value=f'=COUNTIFS({CD("H")},A{r},{CD("R")},"Yes")')
    wsr.cell(row=r, column=4, value=f'=SUMIFS({CD("S")},{CD("H")},A{r})'); wsr.cell(row=r, column=5, value=f'=SUMIFS({CD("T")},{CD("H")},A{r})')
    wsr.cell(row=r, column=6, value=f"=IF(D{r}=0,0,E{r}/D{r})")
    wsr.cell(row=r, column=7, value=f"=INDEX('Salesperson Master'!$D$2:$D${SM_LAST},MATCH(A{r},'Salesperson Master'!$B$2:$B${SM_LAST},0))")
    wsr.cell(row=r, column=8, value=f"=IF(G{r}=0,0,D{r}/G{r})")
    wsr.cell(row=r, column=9, value=f'=IF(H{r}>=1,"Target Achieved",IF(H{r}>=0.9,"Near Target","Below Target"))')
    wsr.cell(row=r, column=10, value=f"=RANK(D{r},$D$5:$D${4+len(sp)})")
ST = 5 + len(sp); wsr.cell(row=ST, column=1, value="TOTAL")
for c in (3, 4, 5, 7): wsr.cell(row=ST, column=c, value=f"=SUM({L(c)}5:{L(c)}{ST-1})")
wsr.cell(row=ST, column=6, value=f"=IF(D{ST}=0,0,E{ST}/D{ST})"); wsr.cell(row=ST, column=8, value=f"=IF(G{ST}=0,0,D{ST}/G{ST})")
style_body(wsr, 5, ST, 1, 10, {3: INT, 4: INR, 5: INR, 6: PCT, 7: INR, 8: PCT, 10: "0"}); total_row(wsr, ST, 1, 10); widths(wsr, [18, 10, 13, 15, 15, 14, 15, 14, 17, 8]); wsr.freeze_panes = "B5"
sc = BarChart(); sc.type = "bar"; sc.title = "Salesperson Net Revenue"; sc.height, sc.width = 9, 16
sc.add_data(Reference(wsr, min_col=4, min_row=4, max_row=ST - 1), titles_from_data=True); sc.set_categories(Reference(wsr, min_col=1, min_row=5, max_row=ST - 1))
sc.legend = None; sc.roundedCorners = False; sc.x_axis.delete = False; sc.y_axis.delete = False; sc.title.overlay = False; sc.x_axis.scaling.orientation = "maxMin"; sc.y_axis.numFmt = "#,##0"
sc.series[0].graphicalProperties.solidFill = TEAL; wsr.add_chart(sc, "A20")

# ---------------- Status & Payment ----------------
wsp = sheet("Status & Payment", TEAL); title(wsp, "Order Status & Payment Mode Analysis", "COUNTIFS / SUMIFS on ALL orders (cancelled and returned included)")
header(wsp, 4, ["Order Status", "Orders", "% of Orders", "Booked Value"])
for k, s in enumerate(["Delivered", "Shipped", "Cancelled", "Returned"]):
    r = 5 + k; wsp.cell(row=r, column=1, value=s); wsp.cell(row=r, column=2, value=f'=COUNTIF({CD("O")},A{r})')
    wsp.cell(row=r, column=3, value=f"=B{r}/$B$9"); wsp.cell(row=r, column=4, value=f'=SUMIFS({CD("K")},{CD("O")},A{r})')
wsp.cell(row=9, column=1, value="TOTAL"); wsp.cell(row=9, column=2, value="=SUM(B5:B8)"); wsp.cell(row=9, column=3, value="=SUM(C5:C8)"); wsp.cell(row=9, column=4, value="=SUM(D5:D8)")
style_body(wsp, 5, 9, 1, 4, {2: INT, 3: PCT, 4: INR}); total_row(wsp, 9, 1, 4)
header(wsp, 12, ["Payment Mode", "Orders", "Cancelled", "Cancellation Rate %", "Net Revenue", "Risk Flag"])
for k, p in enumerate(["UPI", "Credit Card", "Debit Card", "Net Banking", "COD", "Wallet", "Unknown"]):
    r = 13 + k; wsp.cell(row=r, column=1, value=p); wsp.cell(row=r, column=2, value=f'=COUNTIF({CD("N")},A{r})')
    wsp.cell(row=r, column=3, value=f'=COUNTIFS({CD("N")},A{r},{CD("O")},"Cancelled")'); wsp.cell(row=r, column=4, value=f"=IF(B{r}=0,0,C{r}/B{r})")
    wsp.cell(row=r, column=5, value=f'=SUMIFS({CD("S")},{CD("N")},A{r})'); wsp.cell(row=r, column=6, value=f'=IF(D{r}>=0.1,"High Risk",IF(D{r}>=0.06,"Watch","OK"))')
style_body(wsp, 13, 19, 1, 6, {2: INT, 3: INT, 4: PCT, 5: INR}); widths(wsp, [16, 12, 12, 20, 16, 12])
oc = BarChart(); oc.type = "col"; oc.title = "Orders by Status"; oc.height, oc.width = 7.5, 12
oc.add_data(Reference(wsp, min_col=2, min_row=4, max_row=8), titles_from_data=True); oc.set_categories(Reference(wsp, min_col=1, min_row=5, max_row=8))
oc.legend = None; oc.roundedCorners = False; oc.x_axis.delete = False; oc.y_axis.delete = False; oc.title.overlay = False; oc.series[0].graphicalProperties.solidFill = TEAL
wsp.add_chart(oc, "H4")

# ---------------- Customer Master (for unique customer count & top customers) ----------------
wcu = sheet("Customer Master", "A6A6A6"); header(wcu, 1, ["Customer ID", "Customer Name", "Region", "Valid Orders", "Net Revenue", "Customer Tier"])
for i, r in enumerate(cu.itertuples(index=False), 2):
    for j, v in enumerate(r, 1): wcu.cell(row=i, column=j, value=v)
    wcu.cell(row=i, column=4, value=f'=COUNTIFS({CD("C")},A{i},{CD("R")},"Yes")'); wcu.cell(row=i, column=5, value=f'=SUMIFS({CD("S")},{CD("C")},A{i})')
    wcu.cell(row=i, column=6, value=f'=IF(D{i}=0,"Inactive",IF(E{i}>=150000,"Gold",IF(E{i}>=50000,"Silver","Bronze")))')
CU_LAST = len(cu) + 1; style_body(wcu, 2, CU_LAST, 1, 6, {4: INT, 5: INR}); widths(wcu, [13, 22, 10, 13, 15, 14]); wcu.freeze_panes = "A2"; wcu.auto_filter.ref = f"A1:F{CU_LAST}"

# ---------------- KPI Dashboard ----------------
wk = wb.create_sheet("KPI Dashboard", 1); wk.sheet_view.showGridLines = False; wk.sheet_properties.tabColor = "C00000"
title(wk, "Sales MIS - KPI Dashboard", "Jan-2024 to Dec-2025 | Valid sales only (excludes Cancelled & Returned) | Currency INR")
cards = [("Total Revenue", f"=SUM({CD('S')})", INR), ("Total Profit", f"=SUM({CD('T')})", INR), ("Total Orders", f'=COUNTIF({CD("R")},"Yes")', INT),
         ("Total Customers", f'=COUNTIF(\'Customer Master\'!$D$2:$D${CU_LAST},">0")', INT), ("Avg Order Value", "=A5/C5", INR), ("Profit Margin", "=B5/A5", PCT)]
for k, (lab, f, fmt) in enumerate(cards):
    c = 1 + k
    a = wk.cell(row=4, column=c, value=lab); a.font = F(bold=True, color="FFFFFF", size=10); a.fill = PatternFill("solid", fgColor=TEAL); a.alignment = Alignment(horizontal="center")
    b = wk.cell(row=5, column=c, value=f); b.font = F(bold=True, size=16, color=NAVY); b.number_format = fmt; b.alignment = Alignment(horizontal="center", vertical="center"); b.fill = PatternFill("solid", fgColor=LIGHT)
wk.row_dimensions[5].height = 38
for c in range(1, 7): wk.column_dimensions[L(c)].width = 20
wk["A7"] = "Supporting metrics"; wk["A7"].font = F(bold=True, color=NAVY, size=12)
sup = [("All orders booked (incl. cancelled/returned)", f"=COUNTA({CD('A')})", INT), ("Gross booked revenue", f"=SUM({CD('K')})", INR),
       ("Cancellation rate", f'=COUNTIF({CD("O")},"Cancelled")/COUNTA({CD("A")})', "0.00%"), ("Return rate", f'=COUNTIF({CD("O")},"Returned")/COUNTA({CD("A")})', "0.00%"),
       ("Value lost to cancel + return", "=B9-A5", INR), ("Best month (revenue)", f"=INDEX('Monthly Report'!$A${M1}:$A${M2},MATCH(MAX('Monthly Report'!$C${M1}:$C${M2}),'Monthly Report'!$C${M1}:$C${M2},0))", MON),
       ("Top region", f"=INDEX('Region Report'!$A$5:$A$9,MATCH(1,'Region Report'!$I$5:$I$9,0))", None),
       ("Top product", f"=INDEX('Product Report'!$A$5:$A${PT-1},MATCH(1,'Product Report'!$I$5:$I${PT-1},0))", None),
       ("Top salesperson", f"=INDEX('Salesperson Report'!$A$5:$A${ST-1},MATCH(1,'Salesperson Report'!$J$5:$J${ST-1},0))", None)]
for k, (lab, f, fmt) in enumerate(sup):
    r = 8 + k; wk.cell(row=r, column=1, value=lab).font = F(); c = wk.cell(row=r, column=2, value=f); c.font = F(bold=True); c.alignment = Alignment(horizontal="right")
    if fmt: c.number_format = fmt
    wk.cell(row=r, column=1).border = BORDER; c.border = BORDER
# NOTE: B9 = gross booked revenue, A5 = net revenue card -> value lost = B9 - A5
wk.column_dimensions["A"].width = 42
ch2 = LineChart(); ch2.title = "Monthly Net Revenue"; ch2.height, ch2.width = 7.5, 17
ch2.add_data(Reference(wm, min_col=3, min_row=4, max_row=M2), titles_from_data=True); ch2.set_categories(Reference(wm, min_col=1, min_row=M1, max_row=M2))
ch2.legend = None; ch2.roundedCorners = False; ch2.x_axis.delete = False; ch2.y_axis.delete = False; ch2.title.overlay = False; ch2.x_axis.number_format = "mmm-yy"; ch2.y_axis.numFmt = "#,##0"
ch2.series[0].graphicalProperties.line.solidFill = TEAL; wk.add_chart(ch2, "A19")
ch3 = BarChart(); ch3.type = "col"; ch3.title = "Net Revenue by Region"; ch3.height, ch3.width = 7.5, 12
ch3.add_data(Reference(wrg, min_col=4, min_row=4, max_row=9), titles_from_data=True); ch3.set_categories(Reference(wrg, min_col=1, min_row=5, max_row=9))
ch3.legend = None; ch3.roundedCorners = False; ch3.x_axis.delete = False; ch3.y_axis.delete = False; ch3.title.overlay = False; ch3.y_axis.numFmt = "#,##0"; ch3.series[0].graphicalProperties.solidFill = NAVY
wk.add_chart(ch3, "E19")

# ---------------- Lookup Tool ----------------
wl = sheet("Lookup Tool", "FFC000"); title(wl, "Order Lookup Tool", "Type an Order ID in the yellow cell. Demonstrates VLOOKUP and INDEX/MATCH.")
wl["A4"] = "Enter Order ID:"; wl["A4"].font = F(bold=True); wl["B4"] = "ORD-100250"; wl["B4"].fill = PatternFill("solid", fgColor="FFFF00"); wl["B4"].font = F(bold=True, color="0000FF"); wl["B4"].border = BORDER
fields = [("Order Date", 2, DATE), ("Customer Name", 4, None), ("Product", 5, None), ("Category", 6, None), ("Region", 7, None), ("Salesperson", 8, None),
          ("Quantity", 9, None), ("Revenue", 11, INR), ("Profit", 13, INR), ("Order Status", 15, None)]
header(wl, 6, ["Field", "VLOOKUP result", "INDEX/MATCH result"])
for k, (lab, col, fmt) in enumerate(fields):
    r = 7 + k; wl.cell(row=r, column=1, value=lab)
    wl.cell(row=r, column=2, value=f"=IFERROR(VLOOKUP($B$4,'Cleaned Data'!$A$2:$U${LAST},{col},FALSE),\"Not found\")")
    wl.cell(row=r, column=3, value=f"=IFERROR(INDEX({CD(L(col))},MATCH($B$4,{CD('A')},0)),\"Not found\")")
    for c in (2, 3):
        if fmt: wl.cell(row=r, column=c).number_format = fmt
style_body(wl, 7, 16, 1, 3, {}); 
for k, (lab, col, fmt) in enumerate(fields):
    for c in (2, 3):
        if fmt: wl.cell(row=7 + k, column=c).number_format = fmt
widths(wl, [20, 28, 28])
wl["A19"] = "Why both?  VLOOKUP needs the lookup column on the LEFT; INDEX/MATCH works in any direction and is faster on large data."; wl["A19"].font = F(italic=True)

# ---------------- Pivot Guide ----------------
wg = sheet("Pivot Guide", "FFC000"); title(wg, "How to build PivotTables from this workbook")
steps = [
 "1. Go to 'Cleaned Data' and click any cell inside the table (named tblSales).",
 "2. Insert > PivotTable > New Worksheet > OK.",
 "PIVOT 1 - Monthly revenue: Rows = Month, Values = Sum of Net Revenue, Sum of Net Profit. Format Month as mmm-yyyy.",
 "PIVOT 2 - Region x Category: Rows = Region, Columns = Category, Values = Sum of Net Revenue.",
 "PIVOT 3 - Product performance: Rows = Product Name, Values = Sum of Net Revenue; sort Largest to Smallest; Value Filter > Top 10.",
 "PIVOT 4 - Salesperson: Rows = Salesperson, Values = Sum of Net Revenue, Count of Order ID (filter Valid Sale = Yes).",
 "PIVOT 5 - Order status: Rows = Order Status, Values = Count of Order ID, Sum of Revenue (shows 'Show Values As > % of Grand Total').",
 "Add Slicers: PivotTable Analyze > Insert Slicer > Region, Category, Year. Connect one slicer to many pivots via Report Connections.",
 "Tip: set Valid Sale = Yes as a Report Filter, or use the Net Revenue / Net Profit columns that already exclude cancelled/returned orders.",
 "After adding new data: Data > Refresh All.",
]
for i, t in enumerate(steps, 3): wg.cell(row=i, column=1, value=t).font = F()
wg.column_dimensions["A"].width = 140

order = ["README", "KPI Dashboard", "Raw Data", "Cleaned Data", "Monthly Report", "Region Report", "Category Report", "Product Report",
         "Salesperson Report", "Status & Payment", "Lookup Tool", "Pivot Guide", "Product Master", "Salesperson Master", "Customer Master"]
wb._sheets = [wb[n] for n in order]
os.makedirs(f"{BASE}/Excel", exist_ok=True)
wb.save(f"{BASE}/Excel/Sales_MIS_Report.xlsx"); print("saved")
