"""04_build_html_dashboard.py -> PowerBI/Interactive_Dashboard.html : a working, filterable dashboard (double-click to open in a browser).
Same KPIs/charts/slicers as the Power BI design. Needs internet once (loads Chart.js from a CDN)."""
import os, json
import pandas as pd
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
df = pd.read_csv(f"{BASE}/Dataset/sales_cleaned.csv")
dims = {c: sorted(df[c].unique()) for c in ["Region", "Category", "Product Name", "Salesperson"]}
status = ["Delivered", "Shipped", "Cancelled", "Returned"]; custs = {c: i for i, c in enumerate(sorted(df["Customer ID"].unique()))}
rows = [[r["Order Date"], dims["Region"].index(r["Region"]), dims["Category"].index(r["Category"]), dims["Product Name"].index(r["Product Name"]),
         dims["Salesperson"].index(r["Salesperson"]), status.index(r["Order Status"]), int(r["Revenue"]), int(r["Profit"]), custs[r["Customer ID"]]]
        for _, r in df.iterrows()]
HTML = r"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sales MIS Dashboard</title><script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
:root{--bg:#F4F6FA;--card:#fff;--ink:#1F3864;--mut:#6b7280;--acc:#2E75B6;--line:#e5e7eb}
@media(prefers-color-scheme:dark){:root{--bg:#0f172a;--card:#1e293b;--ink:#e2e8f0;--mut:#94a3b8;--acc:#60a5fa;--line:#334155}}
*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:var(--bg);color:var(--ink);padding:16px}
h1{font-size:20px;margin:0}p.s{margin:2px 0 12px;color:var(--mut);font-size:12px}
.f{display:flex;flex-wrap:wrap;gap:10px;background:var(--card);padding:10px;border-radius:8px;margin-bottom:12px;border:1px solid var(--line)}
.f label{font-size:11px;color:var(--mut);display:flex;flex-direction:column;gap:3px}.f select,.f input,.f button{padding:5px;border-radius:5px;border:1px solid var(--line);background:var(--bg);color:var(--ink);font-size:12px}
.f button{cursor:pointer;align-self:flex-end;background:var(--acc);color:#fff;border:0}
.k{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:12px}
.k div{background:var(--card);border-radius:8px;padding:10px;border-top:4px solid var(--acc);text-align:center;border-left:1px solid var(--line);border-right:1px solid var(--line);border-bottom:1px solid var(--line)}
.k b{display:block;font-size:22px}.k span{font-size:11px;color:var(--mut)}
.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:12px}.c{background:var(--card);border-radius:8px;padding:10px;border:1px solid var(--line)}
.c h3{margin:0 0 6px;font-size:13px}.w{position:relative;height:250px}
</style></head><body>
<h1>Sales MIS Reporting &amp; Business Performance Dashboard</h1><p class="s">Valid sales exclude Cancelled &amp; Returned orders. Order Status chart shows all orders. Currency: INR.</p>
<div class="f"><label>From<input type="date" id="d1"></label><label>To<input type="date" id="d2"></label>
<label>Region<select id="fr"></select></label><label>Category<select id="fc"></select></label><label>Salesperson<select id="fs"></select></label><button onclick="reset()">Reset</button></div>
<div class="k" id="k"></div>
<div class="g"><div class="c"><h3>Monthly Revenue Trend</h3><div class="w"><canvas id="c1"></canvas></div></div><div class="c"><h3>Region-wise Sales</h3><div class="w"><canvas id="c2"></canvas></div></div>
<div class="c"><h3>Category-wise Revenue</h3><div class="w"><canvas id="c3"></canvas></div></div><div class="c"><h3>Top 10 Products</h3><div class="w"><canvas id="c4"></canvas></div></div>
<div class="c"><h3>Salesperson Performance</h3><div class="w"><canvas id="c5"></canvas></div></div><div class="c"><h3>Order Status Analysis</h3><div class="w"><canvas id="c6"></canvas></div></div></div>
<script>
const D=__DATA__,ST=["Delivered","Shipped","Cancelled","Returned"],P=["#2E75B6","#1F3864","#9DC3E6","#ED7D31","#A5A5A5","#C00000"];
const R=D.rows,dt=R.map(r=>r[0]);document.getElementById("d1").value=dt[0];document.getElementById("d2").value=dt[dt.length-1];
function fill(id,list){const s=document.getElementById(id);s.innerHTML='<option value="-1">All</option>'+list.map((x,i)=>`<option value="${i}">${x}</option>`).join("");s.onchange=draw}
fill("fr",D.dims.Region);fill("fc",D.dims.Category);fill("fs",D.dims.Salesperson);d1.onchange=d2.onchange=draw;
const inr=n=>"₹"+Math.round(n).toLocaleString("en-IN"),cr=n=>"₹"+(n/1e7).toFixed(2)+" Cr",L=n=>"₹"+(n/1e5).toFixed(1)+"L";
const CH={};function chart(id,type,labels,data,opt={}){const cfg={type,data:{labels,datasets:[{data,backgroundColor:opt.colors||P[0],borderColor:P[0],fill:false,tension:.3}]},
options:{responsive:true,maintainAspectRatio:false,indexAxis:opt.h?"y":"x",plugins:{legend:{display:type=="doughnut",position:"right"}},scales:type=="doughnut"?{}:{x:{ticks:{color:"#888",maxRotation:60}},y:{ticks:{color:"#888",callback:v=>opt.cnt?v:(opt.h?undefined:L(v))}}}}};
if(opt.h){cfg.options.scales.x.ticks.callback=v=>L(v);cfg.options.scales.y.ticks.callback=undefined}
if(CH[id])CH[id].destroy();CH[id]=new Chart(document.getElementById(id),cfg)}
function sum(rows,fn){const m={};rows.forEach(r=>{const k=fn(r);m[k]=(m[k]||0)+r[6]});return m}
function draw(){const a=d1.value,b=d2.value,fr=+fr_.value,fc=+fc_.value,fs=+fs_.value;
const rows=R.filter(r=>r[0]>=a&&r[0]<=b&&(fr<0||r[1]==fr)&&(fc<0||r[2]==fc)&&(fs<0||r[4]==fs)),v=rows.filter(r=>r[5]<2);
const rev=v.reduce((s,r)=>s+r[6],0),pr=v.reduce((s,r)=>s+r[7],0),cu=new Set(v.map(r=>r[8])).size;
k.innerHTML=[["Total Revenue",cr(rev)],["Total Profit",cr(pr)],["Total Orders",v.length.toLocaleString("en-IN")],["Total Customers",cu],["Avg Order Value",inr(v.length?rev/v.length:0)],["Profit Margin",(rev?100*pr/rev:0).toFixed(1)+"%"]].map(x=>`<div><b>${x[1]}</b><span>${x[0]}</span></div>`).join("");
const mo=sum(v,r=>r[0].slice(0,7));const mk=Object.keys(mo).sort();chart("c1","line",mk,mk.map(x=>mo[x]));
const rg=sum(v,r=>D.dims.Region[r[1]]);const rk=Object.keys(rg).sort((x,y)=>rg[y]-rg[x]);chart("c2","bar",rk,rk.map(x=>rg[x]));
const ct=sum(v,r=>D.dims.Category[r[2]]);const ck=Object.keys(ct);chart("c3","doughnut",ck,ck.map(x=>ct[x]),{colors:P});
const pd_=sum(v,r=>D.dims["Product Name"][r[3]]);const pk=Object.keys(pd_).sort((x,y)=>pd_[y]-pd_[x]).slice(0,10);chart("c4","bar",pk,pk.map(x=>pd_[x]),{h:1,colors:P[1]});
const sp=sum(v,r=>D.dims.Salesperson[r[4]]);const sk=Object.keys(sp).sort((x,y)=>sp[y]-sp[x]);chart("c5","bar",sk,sk.map(x=>sp[x]),{h:1});
const sc=ST.map((_,i)=>rows.filter(r=>r[5]==i).length);chart("c6","bar",ST,sc,{cnt:1,colors:[P[0],P[2],P[3],P[5]]})}
const fr_=document.getElementById("fr"),fc_=document.getElementById("fc"),fs_=document.getElementById("fs"),k=document.getElementById("k");
function reset(){d1.value=dt[0];d2.value=dt[dt.length-1];fr_.value=fc_.value=fs_.value=-1;draw()}draw();
</script></body></html>"""
data = {"dims": dims, "rows": rows}
os.makedirs(f"{BASE}/PowerBI", exist_ok=True)
open(f"{BASE}/PowerBI/Interactive_Dashboard.html", "w", encoding="utf-8").write(HTML.replace("__DATA__", json.dumps(data, separators=(",", ":"))))
print("html saved", os.path.getsize(f"{BASE}/PowerBI/Interactive_Dashboard.html") // 1024, "KB")
