"""
05_build_sqlite_db.py  -> builds SQL/sales_mis.db from the CSV files, runs every query in the .sql files,
and saves the sample outputs to SQL/sample_query_results.md (so you can see what each query returns).
Open sales_mis.db with 'DB Browser for SQLite' (free) or run: sqlite3 ../SQL/sales_mis.db < ../SQL/04_business_analysis.sql
"""
import os, re, sqlite3
import pandas as pd

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DS, SQL = f"{BASE}/Dataset", f"{BASE}/SQL"
db = f"{SQL}/sales_mis.db"
if os.path.exists(db): os.remove(db)
con = sqlite3.connect(db)
con.executescript(open(f"{SQL}/01_create_tables.sql", encoding="utf-8").read())

s = pd.read_csv(f"{DS}/sales_cleaned.csv")
s.columns = [c.lower().replace(" ", "_") for c in s.columns]
s.to_sql("sales", con, if_exists="append", index=False)
for t in ["products", "salespeople", "customers"]:
    pd.read_csv(f"{DS}/{t}.csv").to_sql(t, con, if_exists="append", index=False)
con.commit()
print({t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ["sales", "products", "salespeople", "customers"]})

out = ["# Sample query results (first 12 rows of each query)\n"]
for f in ["02_select_where_groupby.sql", "03_joins_subqueries.sql", "04_business_analysis.sql"]:
    text = open(f"{SQL}/{f}", encoding="utf-8").read()
    for block in re.split(r"\n(?=-- Q\d+\.)", text):
        m = re.match(r"-- (Q\d+\..*)", block)
        if not m: continue
        stmt = "\n".join(l for l in block.splitlines() if not l.startswith("--")).strip().rstrip(";")
        df = pd.read_sql_query(stmt, con)
        out.append(f"## {m.group(1)}  ({f})\nRows returned: {len(df)}\n\n{df.head(12).to_markdown(index=False) if len(df) else '_(no rows - expected)_'}\n")
        print("OK", m.group(1)[:60], "->", len(df), "rows")
open(f"{SQL}/sample_query_results.md", "w", encoding="utf-8").write("\n".join(out))
con.close()
