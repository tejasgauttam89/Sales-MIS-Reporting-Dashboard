"""Runs the whole pipeline in order:  python run_all.py"""
import subprocess, sys, os
here = os.path.dirname(os.path.abspath(__file__))
for s in ["01_generate_dataset.py", "02_clean_and_analyze.py", "03_generate_charts.py", "04_build_html_dashboard.py",
          "05_build_sqlite_db.py", "06_build_excel_workbook.py"]:
    print(f"\n>>> {s}"); subprocess.run([sys.executable, os.path.join(here, s)], check=True, cwd=here)
print("\nDone. NOTE: open Excel/Sales_MIS_Report.xlsx once and press Ctrl+Alt+F9 (or just open it - Excel recalculates formulas automatically).")
