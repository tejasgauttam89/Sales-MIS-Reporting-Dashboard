"""
02_clean_and_analyze.py
Loads the raw sales file -> cleans it -> calculates KPIs -> analyses trends -> writes business insights.
Run:  python 02_clean_and_analyze.py
Outputs: Dataset/sales_cleaned.csv, Python/output/kpis.json, Python/output/cleaning_log.txt, Python/output/business_insights.md
"""
import os, json
import pandas as pd
import numpy as np

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DS, OUT = os.path.join(BASE, "Dataset"), os.path.join(BASE, "Python", "output")
os.makedirs(OUT, exist_ok=True)
log = []
def note(msg):
    print(msg); log.append(msg)

# ============ 1. LOAD ============
raw = pd.read_csv(f"{DS}/sales_raw.csv", dtype=str)
note(f"1. Loaded raw file: {len(raw):,} rows x {raw.shape[1]} columns")
note(f"   Missing values before cleaning:\n{raw.isna().sum()[raw.isna().sum() > 0].to_string()}")

# ============ 2. CLEAN ============
df = raw.copy()
df = df.apply(lambda s: s.str.strip())                                   # trim spaces everywhere

before = len(df)
df = df.drop_duplicates()                                                # exact duplicate rows
note(f"2. Removed {before - len(df)} exact duplicate rows -> {len(df):,} rows")
assert df["Order ID"].is_unique, "Order ID still duplicated!"

# mixed date formats: yyyy-mm-dd and dd/mm/yyyy
iso = pd.to_datetime(df["Order Date"], format="%Y-%m-%d", errors="coerce")
dmy = pd.to_datetime(df["Order Date"], format="%d/%m/%Y", errors="coerce")
df["Order Date"] = iso.fillna(dmy)
note(f"3. Parsed dates (two formats found: {int(dmy.notna().sum())} rows were dd/mm/yyyy). Unparsed: {int(df['Order Date'].isna().sum())}")

# text standardisation
df["Customer Name"] = df["Customer Name"].str.title()
df["Region"] = df["Region"].str.title()
df["Order Status"] = df["Order Status"].str.title()

# fill missing Region from salesperson (each salesperson works in exactly one region)
sp_region = df.dropna(subset=["Region"]).groupby("Salesperson")["Region"].agg(lambda s: s.mode()[0])
miss = df["Region"].isna().sum()
df["Region"] = df["Region"].fillna(df["Salesperson"].map(sp_region))
note(f"4. Filled {miss} blank Region values using Salesperson -> Region mapping")

# fill missing Customer Name from Customer ID
cust_name = df.dropna(subset=["Customer Name"]).groupby("Customer ID")["Customer Name"].first()
miss = df["Customer Name"].isna().sum()
df["Customer Name"] = df["Customer Name"].fillna(df["Customer ID"].map(cust_name))
note(f"5. Filled {miss} blank Customer Name values using Customer ID lookup")

miss = df["Payment Mode"].isna().sum()
df["Payment Mode"] = df["Payment Mode"].fillna("Unknown")
note(f"6. Replaced {miss} blank Payment Mode with 'Unknown'")

# numeric types + integrity checks
for c in ["Quantity", "Unit Price", "Revenue", "Cost", "Profit"]:
    df[c] = pd.to_numeric(df[c])
assert (df["Quantity"] * df["Unit Price"] == df["Revenue"]).all(), "Revenue != Qty x Price"
assert (df["Revenue"] - df["Cost"] == df["Profit"]).all(), "Profit != Revenue - Cost"
note("7. Integrity checks passed: Revenue = Qty x Unit Price and Profit = Revenue - Cost for every row")
note(f"   Remaining nulls: {int(df.isna().sum().sum())}")

# derived business columns
df["Year"] = df["Order Date"].dt.year
df["Month"] = df["Order Date"].dt.to_period("M").astype(str)
df["Valid Sale"] = np.where(df["Order Status"].isin(["Cancelled", "Returned"]), "No", "Yes")
df["Net Revenue"] = np.where(df["Valid Sale"] == "Yes", df["Revenue"], 0)
df["Net Profit"] = np.where(df["Valid Sale"] == "Yes", df["Profit"], 0)
df = df.sort_values("Order ID").reset_index(drop=True)
out = df.copy(); out["Order Date"] = out["Order Date"].dt.strftime("%Y-%m-%d")
out.to_csv(f"{DS}/sales_cleaned.csv", index=False)
note(f"8. Saved cleaned file: {len(df):,} rows -> Dataset/sales_cleaned.csv")

# ============ 3. KPIs  (Valid sales = everything except Cancelled / Returned) ============
v = df[df["Valid Sale"] == "Yes"]
inr = lambda x: f"₹{x:,.0f}"
lakh = lambda x: f"₹{x/1e5:,.2f} L"
cr = lambda x: f"₹{x/1e7:,.2f} Cr"
k = dict(
    total_revenue=int(v.Revenue.sum()), total_profit=int(v.Profit.sum()), total_orders=int(len(v)),
    total_customers=int(v["Customer ID"].nunique()), all_orders_booked=int(len(df)),
    gross_booked_revenue=int(df.Revenue.sum()),
)
k["avg_order_value"] = round(k["total_revenue"] / k["total_orders"], 2)
k["profit_margin_pct"] = round(100 * k["total_profit"] / k["total_revenue"], 2)
k["cancel_rate_pct"] = round(100 * (df["Order Status"] == "Cancelled").mean(), 2)
k["return_rate_pct"] = round(100 * (df["Order Status"] == "Returned").mean(), 2)
json.dump(k, open(f"{OUT}/kpis.json", "w"), indent=2)
note("\n=== KPIs ===\n" + json.dumps(k, indent=2))

# ============ 4. ANALYSIS TABLES ============
def grp(col, data=v):
    g = data.groupby(col).agg(Orders=("Order ID", "count"), Revenue=("Revenue", "sum"), Profit=("Profit", "sum"))
    g["Margin %"] = (100 * g.Profit / g.Revenue).round(1)
    g["Share %"] = (100 * g.Revenue / g.Revenue.sum()).round(1)
    return g.sort_values("Revenue", ascending=False)

monthly, region, cat = grp("Month").sort_index(), grp("Region"), grp("Category")
prod, sales, pay = grp("Product Name"), grp("Salesperson"), grp("Payment Mode")
yearly = grp("Year").sort_index()

# ============ 5. INSIGHTS (every number below is computed, none typed by hand) ============
I = []
add = lambda title, text: I.append((title, text))

add("Overall business health",
    f"Valid (non-cancelled, non-returned) sales over 24 months: {len(v):,} orders, {cr(k['total_revenue'])} revenue, "
    f"{cr(k['total_profit'])} profit, margin {k['profit_margin_pct']}%, average order value {inr(k['avg_order_value'])}.")

y24, y25 = yearly.loc[2024, "Revenue"], yearly.loc[2025, "Revenue"]
o_g = 100*(yearly.loc[2025,'Orders']/yearly.loc[2024,'Orders']-1)
aov_g = 100*((yearly.loc[2025,'Revenue']/yearly.loc[2025,'Orders'])/(yearly.loc[2024,'Revenue']/yearly.loc[2024,'Orders'])-1)
add("Year-on-year growth", f"2025 revenue ({cr(y25)}) grew {100*(y25/y24-1):.1f}% over 2024 ({cr(y24)}). "
    f"Order count rose {o_g:.1f}% and average order value rose {aov_g:.1f}%, so growth came from both more customers buying and bigger baskets.")

peak, low = monthly.Revenue.idxmax(), monthly.Revenue.idxmin()
fest = v[v["Order Date"].dt.month.isin([10, 11])].Revenue.sum() / v.Revenue.sum() * 100
add("Festive-season spike", f"Peak month is {peak} ({lakh(monthly.Revenue.max())}); weakest is {low} ({lakh(monthly.Revenue.min())}). "
    f"October + November alone contribute {fest:.1f}% of 2-year revenue (Diwali/festive buying) -> stock and staff planning must start by September.")

top_r, low_r = region.index[0], region.index[-1]
add("Regional concentration", f"{top_r} is the #1 region with {region.loc[top_r,'Share %']}% of revenue; {low_r} is the smallest with only {region.loc[low_r,'Share %']}%. "
    f"Top two regions ({', '.join(region.index[:2])}) together give {region['Share %'].iloc[:2].sum():.1f}% of sales.")

add("Category mix vs profitability", f"{cat.index[0]} brings the most revenue ({cat['Share %'].iloc[0]}% share) but at {cat['Margin %'].iloc[0]}% margin, "
    f"whereas {cat['Margin %'].idxmax()} earns the best margin ({cat['Margin %'].max()}%) and {cat['Margin %'].idxmin()} the lowest ({cat['Margin %'].min()}%).")

top5 = prod.head(5)
add("Product concentration", f"Top 5 products ({', '.join(top5.index)}) generate {top5['Share %'].sum():.1f}% of revenue. "
    f"#1 is {prod.index[0]} alone at {prod['Share %'].iloc[0]}%. Losing stock of these would hurt the most.")

t10 = prod.head(10)
lm = t10["Margin %"].idxmin()
add("High-revenue but low-margin product", f"Among the top-10 products by revenue, {lm} has the thinnest margin ({t10.loc[lm,'Margin %']}%). "
    f"Even a 2% price/cost improvement here would add about {inr(t10.loc[lm,'Revenue']*0.02)}.")

tgt = pd.read_csv(f"{DS}/salespeople.csv").set_index("salesperson_name")["target"]
ach = (sales.Revenue / tgt.reindex(sales.index) * 100).round(1)
add("Salesperson performance", f"{sales.index[0]} leads with {lakh(sales.Revenue.iloc[0])}; {sales.index[-1]} is last with {lakh(sales.Revenue.iloc[-1])} "
    f"({sales.Revenue.iloc[0]/sales.Revenue.iloc[-1]:.1f}x gap). {int((ach>=100).sum())} of {len(ach)} salespeople met their 2-year target; "
    f"best achievement {ach.idxmax()} ({ach.max()}%), lowest {ach.idxmin()} ({ach.min()}%).")

canc, retn = df[df["Order Status"] == "Cancelled"], df[df["Order Status"] == "Returned"]
rr = df.groupby("Category")["Order Status"].apply(lambda s: 100 * (s == "Returned").mean()).round(1)
add("Revenue leakage (cancel + return)", f"{k['cancel_rate_pct']}% of orders were cancelled and {k['return_rate_pct']}% returned, "
    f"locking out {cr(canc.Revenue.sum() + retn.Revenue.sum())} of booked value. {rr.idxmax()} has the highest return rate ({rr.max()}%).")

cod = df[df["Payment Mode"] == "COD"]; pre = df[~df["Payment Mode"].isin(["COD", "Unknown"])]
cr_cod = 100 * (cod["Order Status"] == "Cancelled").mean(); cr_pre = 100 * (pre["Order Status"] == "Cancelled").mean()
add("Cash-on-Delivery risk", f"COD orders are cancelled {cr_cod:.1f}% of the time vs {cr_pre:.1f}% for prepaid modes ({cr_cod/cr_pre:.1f}x higher). "
    f"UPI is the most used mode with {pay.loc['UPI','Share %']}% of revenue -> nudge COD customers to UPI with a small discount.")

lp = pd.read_csv(f"{DS}/products.csv").set_index("product_name")["list_price"]
v = v.assign(Disc=(1 - v["Unit Price"] / v["Product Name"].map(lp)).round(2))
dis, full = v[v.Disc > 0], v[v.Disc == 0]
add("Discount impact", f"{100*len(dis)/len(v):.1f}% of valid orders were sold at a discount (5-10% off list). Their margin is {100*dis.Profit.sum()/dis.Revenue.sum():.1f}% "
    f"vs {100*full.Profit.sum()/full.Revenue.sum():.1f}% for full-price orders, so discounts cost about {inr(( full.Profit.sum()/full.Revenue.sum() - dis.Profit.sum()/dis.Revenue.sum())*dis.Revenue.sum())} "
    f"in profit. Check whether discounted orders actually sell more units before continuing blanket offers.")

cust = v.groupby("Customer ID").Revenue.sum().sort_values(ascending=False)
n10 = int(len(cust) * .10)
rep = (v.groupby("Customer ID").size() > 1).mean() * 100
add("Customer concentration & loyalty", f"Top 10% customers ({n10}) give {100*cust.head(n10).sum()/cust.sum():.1f}% of revenue, and {rep:.1f}% of customers bought more than once. "
    f"A loyalty / key-account programme for the top group is a low-cost way to protect revenue.")

big = v[v.Revenue >= 50000]
add("High-value orders", f"Only {100*len(big)/len(v):.1f}% of orders are worth ₹50,000+, yet they contribute {100*big.Revenue.sum()/v.Revenue.sum():.1f}% of revenue "
    f"(mostly {', '.join(big['Product Name'].value_counts().index[:3])}).")

md = ["# Business Insights - Sales MIS Project", "",
      "_All numbers are auto-calculated by `02_clean_and_analyze.py` from `sales_cleaned.csv`. Valid sales = status not Cancelled/Returned._", ""]
for n, (t, x) in enumerate(I, 1):
    md.append(f"{n}. **{t}** - {x}\n")
open(f"{OUT}/business_insights.md", "w", encoding="utf-8").write("\n".join(md))
open(f"{OUT}/cleaning_log.txt", "w", encoding="utf-8").write("\n".join(log))
for t, x in I: print(f"\n[{t}] {x}")
