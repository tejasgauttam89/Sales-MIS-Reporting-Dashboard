# 📊 Sales MIS Reporting & Business Performance Dashboard

An end-to-end MIS / business-operations project: **5,500 synthetic sales orders (Jan-2024 → Dec-2025)** taken from a messy raw export to a cleaned dataset, formula-driven Excel reports, SQL analysis, a Python (Pandas) pipeline, a Power BI dashboard blueprint and an interactive dashboard.

> **Data note:** all data is synthetic (generated with Python, seed = 42) but modelled on a realistic Indian retail / e-commerce business (INR, regions, festive seasonality, COD cancellations, returns). Created for learning and portfolio use.

## 🎯 Headline results (valid sales = excluding Cancelled & Returned orders)
| Total Revenue | Total Profit | Total Orders | Customers | Avg Order Value | Profit Margin |
|---|---|---|---|---|---|
| ₹3.12 Cr | ₹1.02 Cr | 4,904 | 570 | ₹6,369 | 32.8% |

![Dashboard](Screenshots/00_dashboard_overview.png)

## 📁 Project structure
```
Sales-MIS-Dashboard/
├── Dataset/
│   ├── sales_raw.csv          5,560 rows - DIRTY export (duplicates, blanks, bad text, mixed dates)
│   ├── sales_cleaned.csv      5,500 rows - cleaned + derived columns (Year, Month, Valid Sale, Net Revenue, Net Profit)
│   └── products.csv / salespeople.csv / customers.csv   master tables (dimensions)
├── Excel/
│   └── Sales_MIS_Report.xlsx  15 sheets, ~52,000 live formulas
├── SQL/
│   ├── 01_create_tables.sql  02_select_where_groupby.sql  03_joins_subqueries.sql  04_business_analysis.sql
│   ├── sales_mis.db          ready SQLite database      └── sample_query_results.md  output of all 27 queries
├── PowerBI/
│   ├── PowerBI_Build_Guide.md  DAX_Measures.dax  PowerQuery_Load.m  Sales_MIS_Theme.json
│   └── Interactive_Dashboard.html   working filterable dashboard (opens in any browser)
├── Python/
│   ├── 01_generate_dataset.py  02_clean_and_analyze.py  03_generate_charts.py  04_build_html_dashboard.py
│   ├── 05_build_sqlite_db.py   06_build_excel_workbook.py  run_all.py  requirements.txt
│   └── output/ (cleaning_log.txt, kpis.json, business_insights.md)
├── Screenshots/               dashboard overview + 6 individual chart PNGs
├── Interview_Guide_Hinglish.md   ← read this before interviews
└── README.md
```

## ▶️ How to open and use every file
| File | How to use |
|---|---|
| **Excel/Sales_MIS_Report.xlsx** | Open in Excel 2016+/365. Start at **README** → **KPI Dashboard**. Reports: Monthly, Region, Category, Product, Salesperson, Status & Payment. Type any Order ID in **Lookup Tool** (yellow cell). **Pivot Guide** shows how to create PivotTables from table `tblSales`. Excel recalculates automatically (formulas are live). |
| **SQL/sales_mis.db** | Install free *DB Browser for SQLite* → Open Database → *Execute SQL* tab → paste queries from the `.sql` files. Or terminal: `sqlite3 SQL/sales_mis.db < SQL/04_business_analysis.sql`. For **MySQL**, run `01_create_tables.sql`, import the CSVs (instructions inside the file) and run the other scripts (queries use portable SQL). |
| **Python/** | `pip install -r Python/requirements.txt` then `python Python/run_all.py` (rebuilds everything), or run scripts individually. Python 3.9+. |
| **PowerBI/Interactive_Dashboard.html** | Double-click. Use the Date / Region / Category / Salesperson filters. (Internet needed once to load the Chart.js library.) |
| **PowerBI/PowerBI_Build_Guide.md** | Follow it in Power BI Desktop to create `Sales_MIS_Dashboard.pbix` (45–60 min). Paste measures from `DAX_Measures.dax`, apply `Sales_MIS_Theme.json`. |
| **Screenshots/** | Images for your portfolio. Replace/add real Power BI screenshots after building the `.pbix`. |

## 🧹 Data cleaning performed (Python – `02_clean_and_analyze.py`)
| Issue found in raw file | Fix |
|---|---|
| 60 exact duplicate rows | `drop_duplicates()` → 5,500 unique Order IDs |
| 100 dates as `dd/mm/yyyy`, rest `yyyy-mm-dd` | parsed both formats into real dates |
| 45 blank Region | filled from Salesperson → Region mapping (each seller works in one region) |
| 25 blank Customer Name | filled from Customer ID lookup |
| 35 blank Payment Mode | set to `Unknown` |
| 120 names in CAPS with extra spaces, 80 regions lower-case with spaces, 40 statuses in CAPS | `strip()` + `title()` |
| Integrity | asserted `Revenue = Qty × Unit Price` and `Profit = Revenue − Cost` for all rows |

**Business rule:** *Valid sale* = Order Status ≠ Cancelled/Returned. KPIs use valid sales; the Order Status chart uses all orders.

## 🧮 Excel skills demonstrated
`VLOOKUP` (Category from Product Master) · `INDEX/MATCH` (Region, Target, Lookup Tool; XLOOKUP equivalent noted) · `SUMIFS` · `COUNTIFS` · `COUNTIF` · `IF` / nested `IF` (Valid Sale, Order Band, Margin Flag, Target Status, MoM Trend) · `IFERROR` · `RANK` · `LARGE` · `DATE/YEAR/MONTH` · Excel Table (`tblSales`) · Charts · Freeze panes/filters · Colour coding (blue = inputs) · Pivot guide.

## 🗄️ SQL skills demonstrated (27 tested queries)
`SELECT/WHERE/ORDER BY/LIMIT` · `LIKE/IN/BETWEEN` · `GROUP BY` + `HAVING` · `CASE WHEN` · `INNER/LEFT JOIN`, 3-table JOIN · subqueries (WHERE, FROM, correlated) · CTE (`WITH`) · window functions (`RANK`, `LAG`, running `SUM() OVER`) · monthly revenue, MoM, YoY, Top-10 products, region performance, profit analysis, data-quality check.

## 💡 Business insights (auto-calculated from the data)
1. **Overall business health** - Valid (non-cancelled, non-returned) sales over 24 months: 4,904 orders, ₹3.12 Cr revenue, ₹1.02 Cr profit, margin 32.77%, average order value ₹6,369.

2. **Year-on-year growth** - 2025 revenue (₹1.67 Cr) grew 15.3% over 2024 (₹1.45 Cr). Order count rose 11.9% and average order value rose 3.0%, so growth came from both more customers buying and bigger baskets.

3. **Festive-season spike** - Peak month is 2024-10 (₹16.84 L); weakest is 2024-07 (₹9.17 L). October + November alone contribute 19.5% of 2-year revenue (Diwali/festive buying) -> stock and staff planning must start by September.

4. **Regional concentration** - West is the #1 region with 30.1% of revenue; Central is the smallest with only 8.8%. Top two regions (West, South) together give 55.9% of sales.

5. **Category mix vs profitability** - Electronics brings the most revenue (39.9% share) but at 21.6% margin, whereas Accessories earns the best margin (56.4%) and Electronics the lowest (21.6%).

6. **Product concentration** - Top 5 products (Laptop ProBook 14, Smartphone X1, 4K Smart TV 43in, Air Fryer 4L, Phone Case) generate 39.3% of revenue. #1 is Laptop ProBook 14 alone at 11.5%. Losing stock of these would hurt the most.

7. **High-revenue but low-margin product** - Among the top-10 products by revenue, Laptop ProBook 14 has the thinnest margin (12.8%). Even a 2% price/cost improvement here would add about ₹71,829.

8. **Salesperson performance** - Rohan Mehta leads with ₹43.33 L; Pooja Joshi is last with ₹11.15 L (3.9x gap). 6 of 12 salespeople met their 2-year target; best achievement Ananya Banerjee (108.9%), lowest Karthik Reddy (90.6%).

9. **Revenue leakage (cancel + return)** - 6.05% of orders were cancelled and 4.78% returned, locking out ₹0.44 Cr of booked value. Electronics has the highest return rate (8.5%).

10. **Cash-on-Delivery risk** - COD orders are cancelled 13.0% of the time vs 4.9% for prepaid modes (2.6x higher). UPI is the most used mode with 39.6% of revenue -> nudge COD customers to UPI with a small discount.

11. **Discount impact** - 40.4% of valid orders were sold at a discount (5-10% off list). Their margin is 29.8% vs 34.5% for full-price orders, so discounts cost about ₹548,255 in profit. Check whether discounted orders actually sell more units before continuing blanket offers.

12. **Customer concentration & loyalty** - Top 10% customers (57) give 39.3% of revenue, and 88.4% of customers bought more than once. A loyalty / key-account programme for the top group is a low-cost way to protect revenue.

13. **High-value orders** - Only 1.2% of orders are worth ₹50,000+, yet they contribute 11.7% of revenue (mostly Laptop ProBook 14, 4K Smart TV 43in).

## 🚀 Upload to GitHub (step-by-step)
**Option A – Browser (easiest)**
1. Create a free account at github.com → click **+ → New repository** → name it `Sales-MIS-Dashboard`, tick *Add a README file* is NOT needed (we have one) → **Create repository**.
2. Click **uploading an existing file**, drag the *contents* of this folder (all sub-folders, README.md, .gitignore) → **Commit changes**.
   (Browser upload allows ≤100 files per drop and 25 MB per file – all files here are far below that.)

**Option B – Git command line**
```bash
cd Sales-MIS-Dashboard
git init
git add .
git commit -m "Add Sales MIS Reporting & Business Performance Dashboard project"
git branch -M main
git remote add origin https://github.com/<your-username>/Sales-MIS-Dashboard.git
git push -u origin main
```
**After upload:** add repository *Topics* (`excel`, `power-bi`, `sql`, `python`, `mis`, `data-analysis`), pin the repo on your profile, and paste the link on your resume and LinkedIn.
If you build the `.pbix`, add it to `PowerBI/` and commit again (`git add . && git commit -m "Add Power BI file" && git push`).

## 📝 Resume bullets (edit as you like)
* Built an end-to-end Sales MIS system on 5,500 orders (₹3.12 Cr valid revenue) using Excel, SQL, Python and Power BI; cleaned raw data (60 duplicates, 200+ blank/inconsistent fields) with Pandas.
* Designed a 15-sheet Excel MIS workbook with ~52,000 formulas (SUMIFS, COUNTIFS, INDEX/MATCH, VLOOKUP, IF), automated monthly, regional, product and salesperson-vs-target reports.
* Wrote 27 SQL queries (joins, subqueries, CTEs, window functions) for revenue, profit and customer analysis; surfaced 13 business insights such as COD cancellations being 2.6× prepaid.

## ⚠️ Limitations (be upfront in interviews)
Synthetic data · Excel PivotTables are built by following the Pivot Guide (formula-based summaries are pre-built) · the `.pbix` is created by you in Power BI Desktop using the supplied blueprint; the HTML dashboard is the ready-to-run equivalent.
