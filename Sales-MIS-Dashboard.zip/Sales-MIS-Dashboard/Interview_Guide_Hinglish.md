# 🎤 Interview Guide (Hinglish) – Sales MIS Reporting & Business Performance Dashboard

## 1. 30-second pitch (ise yaad kar lo)
> "Maine ek **Sales MIS Reporting project** banaya hai jisme 5,500 orders ka data hai (Jan 2024 se Dec 2025). Data synthetic hai, lekin real retail business jaisa — regions, festive season, COD cancellations, returns sab included. Maine **Python (Pandas)** se raw data clean kiya, **Excel** me formula-based MIS reports banaye (SUMIFS, COUNTIFS, INDEX-MATCH, VLOOKUP, IF), **SQL** me 27 queries likhi (joins, subqueries, window functions), aur **Power BI** dashboard ka complete blueprint banaya — KPIs, charts aur filters ke saath. Management ko **revenue, profit, orders, region, product aur salesperson performance** ek jagah dikhta hai. Is project se mujhe 13 business insights mile, jaise COD orders ka cancellation prepaid se 2.6 guna zyada hai."

## 2. Project ko step-by-step samjhao
**Step 1 – Dataset:** Python script (`01_generate_dataset.py`) se 5,500 orders banaye. Ek *raw (gandi) file* bhi banayi jisme 60 duplicates, blank values, galat spelling/case aur 2 date formats hain – kyunki real MIS me data kabhi clean nahi aata.

**Step 2 – Cleaning (Pandas):** Duplicates hataye (5,560 → 5,500). Blank Region ko Salesperson se fill kiya (kyunki har salesperson ek hi region me kaam karta hai). Blank Customer Name ko Customer ID se fill kiya. Blank Payment Mode = "Unknown". Text ko `strip()` aur `title()` se standard kiya. Phir check kiya ki **Revenue = Qty × Price** aur **Profit = Revenue − Cost** har row me sahi hai.

**Step 3 – Business rule:** *Valid Sale* = jo order Cancelled ya Returned nahi hai. Revenue/Profit/Orders sirf valid sales se nikalte hain, warna revenue fake high dikhega.

**Step 4 – Excel (15 sheets):** Raw Data, Cleaned Data, Masters, KPI Dashboard, Monthly/Region/Category/Product/Salesperson reports, Status & Payment, Lookup Tool, Pivot Guide. Sab reports **formula se** bane hain, hardcode nahi – data badle to report update ho jaati hai.

**Step 5 – SQL:** `sales_mis.db` me 4 tables (sales, products, salespeople, customers). Queries: filtering, group by/having, joins, subqueries, monthly revenue + MoM growth, top 10 products, region performance, profit analysis.

**Step 6 – Power BI:** Star-schema model (Sales fact + Products, Salespeople, Customers, Date dimensions). 6 KPI cards, 6 charts, 4 slicers (Date, Region, Category, Salesperson). DAX measures `CALCULATE` ke saath valid filter lagake.

**Step 7 – Insights:** Data se 13 insights nikaale aur recommendations diye.

## 3. Key numbers (yaad rakho)
| Metric | Value |
|---|---|
| Total Revenue (valid) | ₹3.12 Cr (₹31,232,361) |
| Total Profit | ₹1.02 Cr — Margin **32.77%** |
| Valid Orders / Customers | 4,904 / 570 |
| Average Order Value | ₹6,369 |
| Cancellation / Return rate | 6.05% / 4.78% |
| 2025 vs 2024 growth | +15.3% |
| Top region | West (30.1%) |
| Top category | Electronics (39.9% revenue, but sirf 21.6% margin) |
| Best margin category | Accessories (56.4%) |
| Top product | Laptop ProBook 14 (11.5% of revenue, margin sirf 12.8%) |
| COD vs prepaid cancellation | 13.0% vs 4.9% |
| Oct + Nov share | 19.5% of revenue (festive season) |

## 4. Formulas – "Ye kaise kiya?"
* **Revenue** = Quantity × Unit Price | **Profit** = Revenue − Cost | **Margin %** = Profit ÷ Revenue | **AOV** = Revenue ÷ Valid Orders
* **Valid Sale:** `=IF(OR(O2="Cancelled",O2="Returned"),"No","Yes")`
* **Monthly revenue:** `=SUMIFS(NetRevenue, MonthColumn, A5)` – SUMIFS multiple conditions ke saath sum karta hai.
* **Orders count:** `=COUNTIFS(Region, A5, ValidSale, "Yes")`
* **Category lookup:** `=VLOOKUP(E2, ProductMaster!B:C, 2, FALSE)`
* **Target lookup:** `=INDEX(Target, MATCH(name, Names, 0))`
* **Growth:** `=C6/C5-1` | **Rank:** `=RANK(D5, D$5:D$29)`

## 5. Common interview questions (Q&A)
**Q1. VLOOKUP aur INDEX-MATCH me kya difference hai?**
VLOOKUP sirf lookup column ke *right* side se value laata hai aur column number hardcode hota hai. INDEX-MATCH left/right dono side kaam karta hai, column insert hone par break nahi hota aur large data me fast hai. XLOOKUP naya function hai jo dono ki problem solve karta hai (Excel 365).

**Q2. SUMIF aur SUMIFS me difference?** SUMIF me 1 condition, SUMIFS me multiple conditions. Dhyan rahe: SUMIFS me *sum range pehle* aata hai, SUMIF me last me.

**Q3. Pivot Table kya hai, kab use karte ho?** Large data ko quickly summarise karne ke liye (drag-drop). Maine Month × Net Revenue, Region × Category, Top 10 products wale pivots ka guide banaya hai. Slicers se interactive banta hai.

**Q4. Data cleaning me kya kiya?** Section 2 (Step 2) bolo – duplicates, blanks, text standardisation, date formats, integrity checks.

**Q5. WHERE vs HAVING?** WHERE grouping se *pehle* rows filter karta hai, HAVING grouping ke *baad* aggregated result filter karta hai. Example: `HAVING COUNT(*) >= 15` (loyal customers).

**Q6. INNER JOIN vs LEFT JOIN?** INNER sirf matching rows deta hai. LEFT JOIN left table ki saari rows deta hai, match na mile to NULL. Mera example: jin customers ne kabhi valid order nahi kiya (30 customers) unko LEFT JOIN + HAVING COUNT = 0 se nikala.

**Q7. Subquery kya hota hai?** Query ke andar query. Example: average order value se bade orders – `WHERE revenue > (SELECT AVG(revenue) ...)`.

**Q8. Window function kyun?** Rows ko collapse kiye bina rank/running total/previous-month value nikalne ke liye – `RANK() OVER`, `LAG()` (MoM growth), `SUM() OVER` (cumulative revenue).

**Q9. Power BI me CALCULATE kya karta hai?** Filter context change karta hai. `Total Revenue = CALCULATE(SUM(Revenue), ValidSale="Yes")` – matlab sirf valid orders ka sum.

**Q10. Star schema kya hai?** Beech me fact table (Sales), uske charo taraf dimension tables (Product, Salesperson, Customer, Date). Relationships one-to-many hoti hain. Isse model fast aur simple rehta hai.

**Q11. Calculated column vs Measure?** Column row-by-row calculate hota hai aur memory me store hota hai; measure filter context ke hisaab se dynamically calculate hota hai (KPIs ke liye measure use karo).

**Q12. MIS Executive ka kaam kya hota hai?** Data collect karna, clean karna, daily/weekly/monthly reports banana, management ko KPIs dena, aur trends/exceptions highlight karna. Ye project exactly wahi dikhata hai.

**Q13. Is data me sabse bada insight kya hai?** "Electronics sabse zyada revenue deta hai but margin sirf 21.6%; Accessories ka margin 56.4% hai. Isliye accessories ko bundle/cross-sell karke profit badha sakte hain. Aur COD ka cancellation 13% hai – UPI ko promote karna chahiye."

**Q14. Aapne data kaise verify kiya?** Excel ke totals ko Pandas aur SQL ke saath match kiya – Revenue ₹31,232,361, Orders 4,904, Customers 570 teeno jagah same.

**Q15. Data real hai?** "Nahi, synthetic hai – Python se banaya. Maine realistic patterns (festive season, COD risk, returns) daale taaki analysis meaningful ho. Process real company data par bhi same chalega." (Seedha sach bolo – interviewers ko pasand aata hai.)

**Q16. Agar naya month ka data aaye to?** Excel: Cleaned Data me rows add karo aur ranges extend karo (ya Table se auto-extend), Refresh All. Power BI: CSV replace karke Refresh. SQL: naye rows INSERT/IMPORT.

**Q17. Aapne kya improve kiya hota agar time hota?** Power BI Service par publish + scheduled refresh, Excel Power Query automation, VBA/Python se daily report email, forecasting (next 3 months).

## 6. Insight-based recommendations (management ko kya bolna hai)
1. September tak festive stock + staff plan karo (Oct–Nov = 19.5% revenue).
2. COD orders par advance/UPI discount do, cancellation kam hoga.
3. Laptop ProBook ki margin 12.8% hai – vendor negotiation ya accessories bundle.
4. Electronics ki return rate (8.5%) high hai – quality check/packing improve karo.
5. Central region sirf 8.8% – naya salesperson ya promo campaign test karo.
6. Discount wale orders ka margin 29.8% vs 34.5% – blanket discounts band karke approval lagao.
7. Top 10% customers 39.3% revenue dete hain – loyalty program.

## 7. Demo kaise do (5 minute flow)
1. `README` + dashboard screenshot dikhao (problem → solution).
2. Excel: KPI Dashboard → Monthly Report (formula bar me SUMIFS dikhao) → Lookup Tool (Order ID type karke).
3. SQL: DB Browser me Top 10 products aur Monthly MoM query run karo.
4. Power BI / HTML dashboard: filter Region = West, dikhao ki sab visuals update hote hain.
5. Python: `cleaning_log.txt` dikhao – before/after.
6. Last me 2–3 insights + recommendation bolo.

## 8. Dhyan rakhne wali baatein
* Hamesha bolo: "Valid sales = Cancelled/Returned hatake." Isse aap business-aware lagte ho.
* Jo cheez nahi aati uske liye bolo: "Mujhe iska basic concept pata hai, hands-on practice kar raha hoon."
* Project ko apne words me explain karne ki practice karo, ratta mat maaro.
